// hooks/index.ts
// NEXORA — Complete custom hooks library

import { useEffect, useRef, useState, useCallback, RefObject } from 'react'

// ─────────────────────────────────────────────────────────────────
// useScrollReveal
// Triggers a CSS class when an element enters the viewport
// ─────────────────────────────────────────────────────────────────
interface ScrollRevealOptions {
  threshold?: number
  rootMargin?: string
  delay?: number
  once?: boolean
  className?: string
}

export function useScrollReveal<T extends HTMLElement = HTMLDivElement>({
  threshold = 0.08,
  rootMargin = '0px',
  delay = 0,
  once = true,
  className = 'visible',
}: ScrollRevealOptions = {}): RefObject<T> {
  const ref = useRef<T>(null)

  useEffect(() => {
    const el = ref.current
    if (!el) return

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => el.classList.add(className), delay * 1000)
          if (once) observer.unobserve(el)
        } else if (!once) {
          el.classList.remove(className)
        }
      },
      { threshold, rootMargin }
    )

    observer.observe(el)
    return () => observer.disconnect()
  }, [threshold, rootMargin, delay, once, className])

  return ref
}

// ─────────────────────────────────────────────────────────────────
// useCountUp
// Animates a number from 0 to target when element enters view
// ─────────────────────────────────────────────────────────────────
interface CountUpOptions {
  target: number
  duration?: number
  suffix?: string
  prefix?: string
  decimals?: number
  easing?: (t: number) => number
}

export function useCountUp({
  target,
  duration = 1400,
  suffix = '+',
  prefix = '',
  decimals = 0,
  easing = (t: number) => 1 - Math.pow(1 - t, 4),
}: CountUpOptions) {
  const [value, setValue] = useState(0)
  const [started, setStarted] = useState(false)
  const ref = useRef<HTMLElement>(null)

  useEffect(() => {
    const el = ref.current
    if (!el) return

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started) {
          setStarted(true)
          const startTime = performance.now()
          const update = (now: number) => {
            const progress = Math.min((now - startTime) / duration, 1)
            const easedProgress = easing(progress)
            setValue(parseFloat((easedProgress * target).toFixed(decimals)))
            if (progress < 1) requestAnimationFrame(update)
          }
          requestAnimationFrame(update)
          observer.unobserve(el)
        }
      },
      { threshold: 0.5 }
    )

    observer.observe(el)
    return () => observer.disconnect()
  }, [target, duration, started, decimals, easing])

  const display = `${prefix}${value.toLocaleString()}${suffix}`
  return { ref, value, display }
}

// ─────────────────────────────────────────────────────────────────
// useMagneticButton
// Makes a button follow the cursor magnetically on hover
// ─────────────────────────────────────────────────────────────────
interface MagneticOptions {
  strength?: number
  radius?: number
}

export function useMagneticButton<T extends HTMLElement = HTMLButtonElement>({
  strength = 0.35,
  radius = 80,
}: MagneticOptions = {}) {
  const ref = useRef<T>(null)

  useEffect(() => {
    const el = ref.current
    if (!el) return

    let bounds: DOMRect
    let animFrame: number

    const onEnter = () => { bounds = el.getBoundingClientRect() }

    const onMove = (e: MouseEvent) => {
      bounds = el.getBoundingClientRect()
      const cx = bounds.left + bounds.width / 2
      const cy = bounds.top + bounds.height / 2
      const dist = Math.hypot(e.clientX - cx, e.clientY - cy)

      if (dist < radius) {
        const dx = (e.clientX - cx) * strength
        const dy = (e.clientY - cy) * strength
        cancelAnimationFrame(animFrame)
        animFrame = requestAnimationFrame(() => {
          el.style.transform = `translate(${dx}px, ${dy}px)`
          el.style.transition = 'transform 0.1s cubic-bezier(0.16,1,0.3,1)'
        })
      }
    }

    const onLeave = () => {
      cancelAnimationFrame(animFrame)
      el.style.transform = 'translate(0,0)'
      el.style.transition = 'transform 0.5s cubic-bezier(0.16,1,0.3,1)'
    }

    el.addEventListener('mouseenter', onEnter)
    el.addEventListener('mousemove', onMove)
    el.addEventListener('mouseleave', onLeave)

    return () => {
      el.removeEventListener('mouseenter', onEnter)
      el.removeEventListener('mousemove', onMove)
      el.removeEventListener('mouseleave', onLeave)
    }
  }, [strength, radius])

  return ref
}

// ─────────────────────────────────────────────────────────────────
// useParallax
// Scroll-driven parallax for a ref element
// ─────────────────────────────────────────────────────────────────
interface ParallaxOptions {
  speed?: number   // 0 = stationary, 1 = scroll speed, -1 = reverse
}

export function useParallax<T extends HTMLElement = HTMLDivElement>({ speed = 0.3 }: ParallaxOptions = {}) {
  const ref = useRef<T>(null)

  useEffect(() => {
    const el = ref.current
    if (!el) return

    let ticking = false

    const update = () => {
      const bounds = el.getBoundingClientRect()
      const center = bounds.top + bounds.height / 2
      const offset = (center - window.innerHeight / 2) * speed
      el.style.transform = `translateY(${offset}px)`
      ticking = false
    }

    const onScroll = () => {
      if (!ticking) { requestAnimationFrame(update); ticking = true }
    }

    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [speed])

  return ref
}

// ─────────────────────────────────────────────────────────────────
// useTheme
// Manages the active demo theme with localStorage persistence
// ─────────────────────────────────────────────────────────────────
export type ThemeId = 'ai' | 'creative' | 'cyber' | 'luxury' | 'motion' | 'agency' | 'freelancer' | '3d'

const THEME_CLASSES: Record<ThemeId, string> = {
  ai:         '',
  creative:   't-creative',
  cyber:      't-cyber',
  luxury:     't-luxury',
  motion:     't-motion',
  agency:     't-agency',
  freelancer: 't-freelancer',
  '3d':       't-3d',
}

export function useTheme(defaultTheme: ThemeId = 'ai') {
  const [theme, setThemeState] = useState<ThemeId>(() => {
    if (typeof window !== 'undefined') {
      return (localStorage.getItem('nexora-theme') as ThemeId) || defaultTheme
    }
    return defaultTheme
  })

  const setTheme = useCallback((id: ThemeId) => {
    Object.values(THEME_CLASSES).forEach(cls => {
      if (cls) document.body.classList.remove(cls)
    })
    const cls = THEME_CLASSES[id]
    if (cls) document.body.classList.add(cls)
    localStorage.setItem('nexora-theme', id)
    setThemeState(id)
  }, [])

  useEffect(() => { setTheme(theme) }, []) // eslint-disable-line react-hooks/exhaustive-deps

  return { theme, setTheme }
}

// ─────────────────────────────────────────────────────────────────
// useNavScroll
// Returns true when user has scrolled past threshold
// ─────────────────────────────────────────────────────────────────
export function useNavScroll(threshold = 50) {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > threshold)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [threshold])

  return scrolled
}

// ─────────────────────────────────────────────────────────────────
// useMediaQuery
// Reactive media query — SSR-safe (returns false on server)
// ─────────────────────────────────────────────────────────────────
export function useMediaQuery(query: string): boolean {
  const [matches, setMatches] = useState(false)

  useEffect(() => {
    const mql = window.matchMedia(query)
    setMatches(mql.matches)
    const handler = (e: MediaQueryListEvent) => setMatches(e.matches)
    mql.addEventListener('change', handler)
    return () => mql.removeEventListener('change', handler)
  }, [query])

  return matches
}

// ─────────────────────────────────────────────────────────────────
// useSkillBars
// Triggers skill bar width animations when container enters view
// ─────────────────────────────────────────────────────────────────
export function useSkillBars(containerRef: RefObject<HTMLElement>) {
  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          container.querySelectorAll<HTMLElement>('[data-width]').forEach(bar => {
            bar.style.width = bar.dataset.width + '%'
          })
          observer.unobserve(container)
        }
      },
      { threshold: 0.15 }
    )

    observer.observe(container)
    return () => observer.disconnect()
  }, [containerRef])
}

// ─────────────────────────────────────────────────────────────────
// useTextSplit
// Splits text into characters for per-char animations
// ─────────────────────────────────────────────────────────────────
export function useTextSplit(text: string) {
  return text.split('').map((char, index) => ({
    char: char === ' ' ? '\u00A0' : char,
    index,
    isSpace: char === ' ',
  }))
}

// ─────────────────────────────────────────────────────────────────
// usePageTransition
// Coordinates page wipe + route change
// ─────────────────────────────────────────────────────────────────
export function usePageTransition() {
  const [transitioning, setTransitioning] = useState(false)

  const transition = useCallback((callback: () => void, duration = 450) => {
    setTransitioning(true)
    setTimeout(() => {
      callback()
      setTimeout(() => setTransitioning(false), duration)
    }, duration)
  }, [])

  return { transitioning, transition }
}

// ─────────────────────────────────────────────────────────────────
// useSmoothScroll (Lenis wrapper)
// ─────────────────────────────────────────────────────────────────
export function useSmoothScroll() {
  useEffect(() => {
    import('@studio-freight/lenis').then(({ default: Lenis }) => {
      const lenis = new Lenis({
        duration: 1.2,
        easing: (t: number) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
        orientation: 'vertical',
        smoothWheel: true,
      })

      const raf = (time: number) => { lenis.raf(time); requestAnimationFrame(raf) }
      requestAnimationFrame(raf)

      return () => lenis.destroy()
    })
  }, [])
}
