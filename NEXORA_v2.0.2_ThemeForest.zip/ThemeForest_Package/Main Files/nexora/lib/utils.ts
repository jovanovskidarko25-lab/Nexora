import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

/** Merges Tailwind classes safely, resolving conflicts. */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/** Clamps a value between min and max. */
export const clamp = (value: number, min: number, max: number) =>
  Math.min(Math.max(value, min), max)

/** Linear interpolation between a and b by t. */
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t

/** Maps a value from one range to another. */
export const mapRange = (
  value: number,
  inMin: number,
  inMax: number,
  outMin: number,
  outMax: number
) => ((value - inMin) / (inMax - inMin)) * (outMax - outMin) + outMin

/** Formats a number as a compact string: 1200 → "1.2k". */
export const formatCompact = (n: number): string =>
  Intl.NumberFormat('en', { notation: 'compact' }).format(n)

/** Returns a slug from a string. */
export const slugify = (str: string) =>
  str.toLowerCase().trim().replace(/\s+/g, '-').replace(/[^\w-]+/g, '')
