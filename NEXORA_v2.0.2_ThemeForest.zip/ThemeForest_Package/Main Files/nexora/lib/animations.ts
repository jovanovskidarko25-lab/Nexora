// lib/animations.ts
// NEXORA — Complete animation system
// Framer Motion variants + easing constants

import { Variants, Transition } from 'framer-motion'

// ─── EASING ─────────────────────────────────────────────────────
export const ease = {
  smooth:    [0.16, 1, 0.3, 1]  as [number, number, number, number], // Expo out — buttery
  snappy:    [0.25, 1, 0.5, 1]  as [number, number, number, number], // Quart out — responsive
  cinematic: [0.76, 0, 0.24, 1] as [number, number, number, number], // Dramatic
  spring:       { type: 'spring', stiffness: 300, damping: 30 },
  springGentle: { type: 'spring', stiffness: 120, damping: 20 },
} as const

// ─── TRANSITIONS ────────────────────────────────────────────────
export const t: Record<string, Transition> = {
  fast:      { duration: 0.3, ease: ease.smooth },
  base:      { duration: 0.5, ease: ease.smooth },
  slow:      { duration: 0.8, ease: ease.smooth },
  cinematic: { duration: 0.9, ease: ease.cinematic },
}

// ─── VARIANT PRESETS ────────────────────────────────────────────
export const fadeUp: Variants = {
  hidden: { opacity: 0, y: 24 },
  show:   { opacity: 1, y: 0, transition: { duration: 0.65, ease: ease.smooth } },
}

export const fadeDown: Variants = {
  hidden: { opacity: 0, y: -24 },
  show:   { opacity: 1, y: 0, transition: { duration: 0.65, ease: ease.smooth } },
}

export const fadeLeft: Variants = {
  hidden: { opacity: 0, x: -28 },
  show:   { opacity: 1, x: 0, transition: { duration: 0.65, ease: ease.smooth } },
}

export const fadeRight: Variants = {
  hidden: { opacity: 0, x: 28 },
  show:   { opacity: 1, x: 0, transition: { duration: 0.65, ease: ease.smooth } },
}

export const scaleIn: Variants = {
  hidden: { opacity: 0, scale: 0.93 },
  show:   { opacity: 1, scale: 1, transition: { duration: 0.6, ease: ease.smooth } },
}

export const blurIn: Variants = {
  hidden: { opacity: 0, filter: 'blur(12px)', y: 12 },
  show:   { opacity: 1, filter: 'blur(0px)', y: 0, transition: { duration: 0.7, ease: ease.smooth } },
}

// ─── STAGGER CONTAINERS ─────────────────────────────────────────
export const staggerContainer = (stagger = 0.08, delay = 0): Variants => ({
  hidden: {},
  show: { transition: { staggerChildren: stagger, delayChildren: delay } },
})

export const staggerFade: Variants = {
  hidden: { opacity: 0, y: 18 },
  show:   { opacity: 1, y: 0, transition: { duration: 0.55, ease: ease.smooth } },
}

// ─── PAGE TRANSITIONS ───────────────────────────────────────────
export const pageIn: Variants = {
  initial: { opacity: 0, y: 16 },
  animate: { opacity: 1, y: 0, transition: { duration: 0.6, ease: ease.smooth } },
  exit:    { opacity: 0, y: -16, transition: { duration: 0.35, ease: ease.snappy } },
}

// Wipe transition (full-page clip-path)
export const wipeIn: Variants = {
  initial: { clipPath: 'inset(0 0 100% 0)' },
  animate: { clipPath: 'inset(0 0 0% 0)', transition: { duration: 0.45, ease: ease.cinematic } },
  exit:    { clipPath: 'inset(100% 0 0 0)', transition: { duration: 0.45, ease: ease.cinematic } },
}

// ─── HERO-SPECIFIC VARIANTS ─────────────────────────────────────
export const heroContainer: Variants = {
  hidden: {},
  show:   { transition: { staggerChildren: 0.1, delayChildren: 0.2 } },
}

export const heroBadge: Variants = {
  hidden: { opacity: 0, scale: 0.92, y: 10 },
  show:   { opacity: 1, scale: 1, y: 0, transition: { duration: 0.55, ease: ease.smooth } },
}

export const heroTitle: Variants = {
  hidden: { opacity: 0, y: 32, filter: 'blur(8px)' },
  show:   { opacity: 1, y: 0, filter: 'blur(0px)', transition: { duration: 0.85, ease: ease.smooth } },
}

export const heroSub: Variants = {
  hidden: { opacity: 0, y: 22 },
  show:   { opacity: 1, y: 0, transition: { duration: 0.7, ease: ease.smooth } },
}
