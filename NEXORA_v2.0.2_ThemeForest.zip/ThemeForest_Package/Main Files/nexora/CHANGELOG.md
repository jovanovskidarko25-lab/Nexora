# NEXORA Changelog

All notable changes to NEXORA are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## [2.0.2] — 2026-05-15

### Fixed — Accessibility (WCAG 2.4 compliance)
- `sections/index.tsx` — Contact form now fully wired to `/api/contact` with real fetch, error handling, `aria-live` status announcements, and `aria-disabled` on the submit button while sending
- `sections/index.tsx` — All form `<input>`, `<textarea>`, `<select>` elements now have `id`, `name`, and associated `<label htmlFor>` attributes (previously missing, breaking screen readers and native form behaviour)
- `sections/index.tsx` — Removed `outline: none` from form elements; keyboard `:focus-visible` ring now correctly inherits the global token-aware rule from `globals.css`
- `app/globals.css` — Added `input:focus-visible / textarea:focus-visible / select:focus-visible` rule with accent-coloured outline + glow (WCAG 2.4.7 — Focus Visible, Level AA)
- `app/globals.css` — Added `.skip-link` skip-to-content component (WCAG 2.4.1 — Bypass Blocks, Level A)
- `app/globals.css` — Added `.sr-only` screen-reader utility class for `aria-live` regions
- `app/layout.tsx` — Added visible skip-to-content `<a class="skip-link">` link before all navigation
- `app/page.tsx` — Added `id="main-content"` anchor target for the skip link
- `app/not-found.tsx` — Added `<Navbar />` so keyboard/screen-reader users have navigation on 404 pages; wrapped content in proper `<main>` / `<>` fragment
- `components/shared/DemosGrid.tsx` — Replaced `<motion.div role="button" tabIndex={0}>` with semantically correct `<motion.button type="button">` (native keyboard activation, no custom `onKeyDown` hack needed)

### Fixed — Bugs
- `sections/index.tsx` — Contact form state is now properly managed (`formData` object, `onChange` handlers, controlled inputs); previously the form was completely uncontrolled with no data capture
- `sections/index.tsx` — Contact form now shows an inline error state on API failure, not just a silent reset
- `sections/index.tsx` — Stale "February 2026" availability copy replaced with "Reach out early — spots fill up quickly."
- `app/about/page.tsx` — Stale "Available Feb 2026" availability badge updated to "Available Now"
- `Index.html` — `cursor: none` on `body` was applied globally, disabling the system cursor on touch/mobile devices; moved inside `@media (pointer: fine)` (matches the React component behaviour)
- `Index.html` — Stale "February 2026" availability copy removed

### Fixed — Documentation
- `DOCUMENTATION.md` — Version updated from 2.0.0 → 2.0.1 (now 2.0.2)
- `DOCUMENTATION.md` — Folder structure corrected: removed references to `lib/gsap.ts`, `lib/three.ts`, `utils/cn.ts`, `utils/format.ts`, `styles/themes/*.css`, `constants/navigation.ts`, `constants/projects.ts` (separate), `constants/testimonials.ts`, `constants/pricing.ts`, `types/demo.ts`, `types/project.ts`, `types/blog.ts` — none of these files exist in the delivered package

---

## [2.0.1] — 2026-05-10

### Fixed
- `app/work/[slug]/page.tsx` — `params` updated to `Promise<{slug}>` for Next.js 15 compatibility
- `app/blog/[slug]/page.tsx` — same Next.js 15 async params fix
- `app/work/[slug]/page.tsx` — `PROJECTS` now imported from `@/constants` (not `@/constants/demos`)
- `app/blog/page.tsx` — blog slug `nextjs-16-performance` aligned with detail page slug list
- `app/api/contact/route.ts` — Resend `from` address now reads `RESEND_FROM_EMAIL` env var
- `sections/index.tsx` — contact email changed from hardcoded `nexora.design` to `your-domain.com` placeholder
- `app/page.tsx` — `DemosGrid` component now properly imported and rendered in the demos section
- `app/contact/page.tsx` — `Contact` section component now properly rendered (was commented out)
- Added `components/shared/DemosGrid.tsx` as a standalone file (was previously missing from zip)
- `.env.local.example` — added `RESEND_FROM_EMAIL` variable

---

## [2.0.0] — 2026-05-10

### Added
- 8 complete homepage demos (AI, Creative, Cyber, Luxury, Motion, Agency, Freelancer, 3D)
- 20+ reusable section components (Hero, Ticker, StatsBar, BentoGrid, Services, About,
  Skills, Timeline, Testimonials, Awards, Pricing, FAQ, Contact, Newsletter, Blog)
- Complete design token system — all 8 themes via CSS custom properties
- Custom cursor with lag ring (mouse/trackpad only, skipped on touch devices)
- Cinematic page-wipe transitions between demos
- Smooth scroll via Lenis
- Interactive 3D hero using React Three Fiber and Drei
- `useScrollReveal`, `useCountUp`, `useMagneticButton`, `useParallax`, `useMediaQuery` hooks
- Full Framer Motion variant library in `lib/animations.ts`
- Blog listing and post pages with static generation
- Contact form API route with Resend integration
- Security headers in `next.config.ts`
- Complete CMS integration guide for Sanity, Contentful, and Notion
- `.env.local.example` with all required variables documented

### Changed
- Upgraded to Next.js 15 (App Router)
- Upgraded to React 19
- Upgraded to Tailwind CSS v4
- Navbar responsive breakpoints now handled via `useMediaQuery` hook
  (previously used unsupported `@media` inside React inline `style` props)
- `cursor: none` now gated behind `@media (pointer: fine)` — touch users
  retain the system cursor
- Removed hardcoded CDN domain from `next.config.ts` `remotePatterns`
- All metadata version references updated to Next.js 15

---

## [1.0.0] — 2025-11-01

### Added
- Initial release with 4 homepage demos
- Basic animation system
- ThemeForest submission
