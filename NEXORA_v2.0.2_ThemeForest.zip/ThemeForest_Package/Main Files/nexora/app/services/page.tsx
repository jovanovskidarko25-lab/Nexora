import type { Metadata } from 'next'
import { SERVICES } from '@/constants/demos'

export const metadata: Metadata = {
  title: 'Services',
  description: 'Premium design and engineering services for modern teams.',
}

export default function ServicesPage() {
  return (
    <main style={{ paddingTop: 120 }}>
      <div style={{ padding: '0 52px 96px', maxWidth: 1280, margin: '0 auto' }}>

        {/* Hero */}
        <div style={{ marginBottom: 80, maxWidth: 700 }}>
          <div style={{ fontSize: 10, letterSpacing: '2.5px', textTransform: 'uppercase',
            color: 'var(--a2)', marginBottom: 18, display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ width: 18, height: 1, background: 'var(--a2)' }} />
            What I Offer
          </div>
          <h1 style={{ fontFamily: 'var(--ff)', fontSize: 'clamp(40px,6vw,72px)',
            fontWeight: 800, letterSpacing: '-3px', lineHeight: 1.0, marginBottom: 20 }}>
            Services built for<br />
            <span style={{ background: 'linear-gradient(135deg,var(--a2),var(--b2))',
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              ambitious teams
            </span>
          </h1>
          <p style={{ fontSize: 17, color: 'var(--muted)', lineHeight: 1.75, fontWeight: 300 }}>
            Premium design and engineering across the full product stack. From initial concept
            to polished, production-ready code.
          </p>
        </div>

        {/* Services grid — detailed */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2,1fr)', gap: 20, marginBottom: 80 }}>
          {SERVICES.map(svc => (
            <div key={svc.num}
              style={{ background: 'var(--card)', border: '1px solid var(--border)',
                borderRadius: 24, padding: 44, transition: 'all .35s' }}>
              <div style={{ fontFamily: 'var(--fm)', fontSize: 10, color: 'var(--a2)',
                letterSpacing: '2px', marginBottom: 22 }}>{svc.num}</div>
              <h2 style={{ fontFamily: 'var(--ff)', fontSize: 24, fontWeight: 700,
                letterSpacing: '-.5px', marginBottom: 14 }}>{svc.title}</h2>
              <p style={{ fontSize: 14, color: 'var(--muted)', lineHeight: 1.7, marginBottom: 28 }}>
                {svc.description}
              </p>
              {/* Deliverables */}
              <div style={{ fontSize: 11, color: 'var(--muted2)', letterSpacing: '1px',
                textTransform: 'uppercase', marginBottom: 12 }}>Deliverables include</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                {getDeliverables(svc.num).map(d => (
                  <span key={d} style={{ background: 'var(--surface)',
                    border: '1px solid var(--border)', borderRadius: 100,
                    padding: '5px 12px', fontSize: 12, color: 'var(--muted)' }}>{d}</span>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div style={{ background: 'linear-gradient(135deg,color-mix(in srgb,var(--a) 8%,var(--card)),var(--card))',
          border: '1px solid color-mix(in srgb,var(--a) 15%,transparent)',
          borderRadius: 28, padding: '64px 52px', textAlign: 'center' }}>
          <h2 style={{ fontFamily: 'var(--ff)', fontSize: 40, fontWeight: 800,
            letterSpacing: '-2px', marginBottom: 16 }}>Ready to start?</h2>
          <p style={{ fontSize: 16, color: 'var(--muted)', marginBottom: 36, fontWeight: 300 }}>
            Tell me about your project and let's figure out which service fits best.
          </p>
          <a href="/contact" style={{ display: 'inline-flex', alignItems: 'center', gap: 8,
            background: 'linear-gradient(135deg,var(--a),var(--c))', color: '#fff',
            padding: '14px 32px', borderRadius: 100, fontSize: 15, fontWeight: 600,
            textDecoration: 'none', boxShadow: '0 6px 24px color-mix(in srgb,var(--a) 30%,transparent)' }}>
            Get In Touch →
          </a>
        </div>
      </div>
    </main>
  )
}

function getDeliverables(num: string): string[] {
  const map: Record<string, string[]> = {
    '01': ['Figma design files', 'Design system', 'Prototype', 'Handoff docs'],
    '02': ['Next.js source code', 'TypeScript', 'Unit tests', 'Deployment'],
    '03': ['Brand guidelines', 'Logo system', 'Color palette', 'Typography'],
    '04': ['GSAP animations', 'Framer Motion', 'SVG sequences', 'Lottie files'],
    '05': ['REST / GraphQL API', 'Database schema', 'Auth system', 'CI/CD'],
    '06': ['Audit report', 'Recommendations', 'Priority roadmap', 'Workshop'],
  }
  return map[num] ?? []
}
