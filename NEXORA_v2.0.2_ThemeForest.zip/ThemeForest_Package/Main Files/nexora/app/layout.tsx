import type { Metadata, Viewport } from 'next'
import {
  Syne,
  DM_Sans,
  JetBrains_Mono,
  Playfair_Display,
  Space_Grotesk,
} from 'next/font/google'
import CustomCursor from '@/components/shared/CustomCursor'
import SmoothScroll from '@/components/shared/SmoothScroll'
import './globals.css'

const syne = Syne({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700', '800'],
  variable: '--font-syne',
  display: 'swap',
})
const dmSans = DM_Sans({
  subsets: ['latin'],
  weight: ['300', '400', '500'],
  variable: '--font-dm',
  display: 'swap',
})
const jetbrains = JetBrains_Mono({
  subsets: ['latin'],
  weight: ['400', '500'],
  variable: '--font-mono',
  display: 'swap',
})
const playfair = Playfair_Display({
  subsets: ['latin'],
  weight: ['700'],
  style: ['normal', 'italic'],
  variable: '--font-playfair',
  display: 'swap',
})
const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600', '700'],
  variable: '--font-space',
  display: 'swap',
})

export const metadata: Metadata = {
  metadataBase: new URL(
    process.env.NEXT_PUBLIC_SITE_URL ?? 'https://your-domain.com'
  ),
  title: {
    default: 'NEXORA — Ultra Premium Portfolio Template',
    template: '%s | NEXORA',
  },
  description:
    'Ultra-premium React portfolio template. 8 homepage demos, 20+ sections, Next.js 15, TypeScript, Framer Motion, GSAP. Built for ThemeForest.',
  keywords: [
    'portfolio template',
    'Next.js template',
    'React portfolio',
    'ThemeForest',
    'framer motion',
    'GSAP animations',
    'premium template',
    'developer portfolio',
  ],
  authors: [{ name: 'NEXORA' }],
  openGraph: {
    type: 'website',
    locale: 'en_US',
    siteName: 'NEXORA Portfolio Template',
    title: 'NEXORA — Ultra Premium Portfolio Template',
    description: '8 unique demos · 20+ sections · Next.js 15 · Framer Motion · GSAP',
    images: [{ url: '/og/default.png', width: 1200, height: 630, alt: 'NEXORA Template Preview' }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'NEXORA — Ultra Premium Portfolio Template',
    description: '8 demos · 20+ sections · Next.js 15 · Premium animations',
    images: ['/og/default.png'],
  },
  robots: { index: true, follow: true },
  icons: {
    icon: '/favicon.ico',
    shortcut: '/favicon-16x16.png',
    apple: '/apple-touch-icon.png',
  },
}

export const viewport: Viewport = {
  themeColor: '#050507',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html
      lang="en"
      suppressHydrationWarning
      className={[
        syne.variable,
        dmSans.variable,
        jetbrains.variable,
        playfair.variable,
        spaceGrotesk.variable,
      ].join(' ')}>
      <body>
        {/* Skip navigation — keyboard and screen-reader users can jump past the nav */}
        <a href="#main-content" className="skip-link">Skip to main content</a>
        <SmoothScroll />
        <CustomCursor />
        {children}
      </body>
    </html>
  )
}
