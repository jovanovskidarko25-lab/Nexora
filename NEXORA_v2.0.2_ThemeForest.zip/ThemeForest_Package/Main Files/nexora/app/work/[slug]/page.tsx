import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { PROJECTS } from '@/constants'

interface Props { params: Promise<{ slug: string }> }

export async function generateStaticParams() {
  return PROJECTS.map(p => ({ slug: p.id }))
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params
  const project = PROJECTS.find(p => p.id === slug)
  if (!project) return {}
  return {
    title: project.title,
    description: project.description,
    openGraph: { title: project.title, description: project.description },
  }
}

export default async function ProjectPage({ params }: Props) {
  const { slug } = await params
  const project = PROJECTS.find(p => p.id === slug)
  if (!project) notFound()

  return (
    <main>
      <ProjectHero project={project} />
      <ProjectContent project={project} />
      <ProjectNav currentId={project.id} />
    </main>
  )
}

function ProjectHero({ project }: { project: typeof PROJECTS[0] }) {
  return (
    <section style={{ minHeight: '60vh', display: 'flex', alignItems: 'flex-end',
      padding: '120px 52px 64px', position: 'relative', overflow: 'hidden' }}>
      {/* Bg orb */}
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
        <div style={{ position: 'absolute', width: 600, height: 600, borderRadius: '50%',
          background: 'radial-gradient(circle,var(--ga),transparent 65%)', top: -200, right: -100 }} />
      </div>
      <div style={{ position: 'relative', zIndex: 1, maxWidth: 1280, margin: '0 auto', width: '100%' }}>
        <div style={{ fontSize: 11, letterSpacing: '2px', textTransform: 'uppercase',
          color: 'var(--a2)', marginBottom: 20 }}>
          {project.category} · {project.year}
        </div>
        <h1 style={{ fontFamily: 'var(--ff)', fontSize: 'clamp(40px,6vw,80px)',
          fontWeight: 800, letterSpacing: '-3px', lineHeight: 1.0, marginBottom: 24,
          maxWidth: 800 }}>{project.title}</h1>
        <p style={{ fontSize: 18, color: 'var(--muted)', maxWidth: 560, lineHeight: 1.7,
          fontWeight: 300, marginBottom: 36 }}>{project.description}</p>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          {project.tags.map(t => (
            <span key={t} style={{ background: 'color-mix(in srgb,var(--a) 10%,transparent)',
              border: '1px solid color-mix(in srgb,var(--a) 18%,transparent)',
              borderRadius: 100, padding: '5px 14px', fontSize: 12, color: 'var(--a2)' }}>
              {t}
            </span>
          ))}
        </div>
      </div>
    </section>
  )
}

function ProjectContent({ project }: { project: typeof PROJECTS[0] }) {
  return (
    <section style={{ padding: '64px 52px', maxWidth: 1280, margin: '0 auto' }}>
      {/* Project preview mockup */}
      <div style={{ width: '100%', height: '60vh', borderRadius: 24,
        background: 'var(--card)', border: '1px solid var(--border)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        position: 'relative', overflow: 'hidden', marginBottom: 64 }}>
        <div style={{ position: 'absolute', inset: 0,
          backgroundImage: `linear-gradient(color-mix(in srgb,var(--a) 10%,transparent) 1px,transparent 1px),
            linear-gradient(90deg,color-mix(in srgb,var(--a) 10%,transparent) 1px,transparent 1px)`,
          backgroundSize: '32px 32px' }} />
        <div style={{ position: 'relative', zIndex: 1, display: 'flex',
          flexDirection: 'column', gap: 12, padding: 32, width: '70%', maxWidth: 600 }}>
          <div style={{ height: 6, borderRadius: 3,
            background: 'linear-gradient(90deg,var(--a),var(--b))', width: '70%' }} />
          {[['ac','',''], ['','ac','ac'], ['ac','','ac'], ['','ac','']].map((row, ri) => (
            <div key={ri} style={{ display: 'flex', gap: 10 }}>
              {row.map((type, ci) => (
                <div key={ci} style={{ height: 32, borderRadius: 8, flex: 1,
                  background: type === 'ac'
                    ? 'color-mix(in srgb,var(--a) 22%,transparent)'
                    : 'rgba(255,255,255,.06)' }} />
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* Stats if available */}
      {project.metric && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)',
          gap: 20, marginBottom: 64 }}>
          <div style={{ background: 'var(--card)', border: '1px solid var(--border)',
            borderRadius: 20, padding: '32px', textAlign: 'center' }}>
            <div style={{ fontFamily: 'var(--ff)', fontSize: 48, fontWeight: 800,
              background: 'linear-gradient(135deg,var(--a2),var(--b2))',
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', lineHeight: 1 }}>
              {project.metric.value}
            </div>
            <div style={{ fontSize: 13, color: 'var(--muted)', marginTop: 8 }}>
              {project.metric.label}
            </div>
          </div>
          <div style={{ background: 'var(--card)', border: '1px solid var(--border)',
            borderRadius: 20, padding: 32, textAlign: 'center' }}>
            <div style={{ fontFamily: 'var(--ff)', fontSize: 48, fontWeight: 800,
              background: 'linear-gradient(135deg,var(--a2),var(--b2))',
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', lineHeight: 1 }}>99</div>
            <div style={{ fontSize: 13, color: 'var(--muted)', marginTop: 8 }}>PageSpeed Score</div>
          </div>
          <div style={{ background: 'var(--card)', border: '1px solid var(--border)',
            borderRadius: 20, padding: 32, textAlign: 'center' }}>
            <div style={{ fontFamily: 'var(--ff)', fontSize: 48, fontWeight: 800,
              background: 'linear-gradient(135deg,var(--a2),var(--b2))',
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', lineHeight: 1 }}>
              {project.year}
            </div>
            <div style={{ fontSize: 13, color: 'var(--muted)', marginTop: 8 }}>Year Delivered</div>
          </div>
        </div>
      )}

      {/* Case study copy */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.5fr', gap: 60, alignItems: 'start' }}>
        <div>
          <div style={{ fontSize: 11, letterSpacing: '2px', textTransform: 'uppercase',
            color: 'var(--a2)', marginBottom: 14 }}>The Challenge</div>
          <p style={{ fontSize: 15, color: 'var(--muted)', lineHeight: 1.8, fontWeight: 300 }}>
            The client needed a complete rebuild of their digital presence — from a fragmented
            multi-tool stack to a unified, premium platform that could scale with their ambitions
            and reflect their position in the market.
          </p>
        </div>
        <div>
          <div style={{ fontSize: 11, letterSpacing: '2px', textTransform: 'uppercase',
            color: 'var(--a2)', marginBottom: 14 }}>The Solution</div>
          <p style={{ fontSize: 15, color: 'var(--muted)', lineHeight: 1.8, fontWeight: 300 }}>
            We designed and built a complete design system in Figma, then implemented it in Next.js
            with TypeScript and Framer Motion. Every micro-interaction was purposeful — from button
            hover states to full-page transitions. The result was a product that felt genuinely
            premium and converted at industry-leading rates.
          </p>
        </div>
      </div>
    </section>
  )
}

function ProjectNav({ currentId }: { currentId: string }) {
  const currentIndex = PROJECTS.findIndex(p => p.id === currentId)
  const prev = PROJECTS[currentIndex - 1]
  const next = PROJECTS[currentIndex + 1]

  return (
    <div style={{ borderTop: '1px solid var(--border)', padding: '48px 52px',
      maxWidth: 1280, margin: '0 auto', display: 'flex',
      justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 20 }}>
      {prev ? (
        <a href={`/work/${prev.id}`} style={{ textDecoration: 'none' }}>
          <div style={{ fontSize: 11, color: 'var(--muted2)', letterSpacing: '1px',
            textTransform: 'uppercase', marginBottom: 6 }}>← Previous</div>
          <div style={{ fontFamily: 'var(--ff)', fontSize: 18, fontWeight: 700,
            color: 'var(--text)' }}>{prev.title}</div>
        </a>
      ) : <div />}
      {next ? (
        <a href={`/work/${next.id}`} style={{ textDecoration: 'none', textAlign: 'right' }}>
          <div style={{ fontSize: 11, color: 'var(--muted2)', letterSpacing: '1px',
            textTransform: 'uppercase', marginBottom: 6 }}>Next →</div>
          <div style={{ fontFamily: 'var(--ff)', fontSize: 18, fontWeight: 700,
            color: 'var(--text)' }}>{next.title}</div>
        </a>
      ) : <div />}
    </div>
  )
}
