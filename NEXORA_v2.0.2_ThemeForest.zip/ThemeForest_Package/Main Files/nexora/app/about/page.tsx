import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'About',
  description: 'Full-stack creative engineer. 8 years crafting premium digital products.',
}

export default function AboutPage() {
  return (
    <main style={{ paddingTop: 120 }}>
      <div style={{ padding: '0 52px 96px', maxWidth: 1280, margin: '0 auto' }}>

        {/* Split hero */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr',
          gap: 80, alignItems: 'start', marginBottom: 96 }}>
          <div>
            <div style={{ fontSize: 10, letterSpacing: '2.5px', textTransform: 'uppercase',
              color: 'var(--a2)', marginBottom: 18, display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ width: 18, height: 1, background: 'var(--a2)' }} />
              About
            </div>
            <h1 style={{ fontFamily: 'var(--ff)', fontSize: 'clamp(36px,5vw,64px)',
              fontWeight: 800, letterSpacing: '-3px', lineHeight: 1.0, marginBottom: 24 }}>
              Building interfaces<br />that feel like<br />
              <span style={{ background: 'linear-gradient(135deg,var(--a2),var(--b2))',
                WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                the future
              </span>
            </h1>
            <p style={{ fontSize: 15, color: 'var(--muted)', lineHeight: 1.8, fontWeight: 300, marginBottom: 20 }}>
              Eight years crafting digital products for startups and Fortune 500 companies.
              My work sits at the intersection of engineering precision and design intuition.
            </p>
            <p style={{ fontSize: 15, color: 'var(--muted)', lineHeight: 1.8, fontWeight: 300, marginBottom: 36 }}>
              I believe great software should be as beautiful as it is functional. Every pixel,
              every transition, every micro-interaction is an opportunity to delight.
            </p>
            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
              {['🇩🇪 Berlin-based', '🌍 Remote-first', '⚡ Available Now'].map(t => (
                <span key={t} style={{ background: 'var(--card)', border: '1px solid var(--border)',
                  borderRadius: 100, padding: '7px 16px', fontSize: 12, color: 'var(--muted)' }}>{t}</span>
              ))}
            </div>
          </div>

          {/* Avatar placeholder with gradient */}
          <div style={{ aspectRatio: '4/5', borderRadius: 28,
            background: 'linear-gradient(135deg,color-mix(in srgb,var(--a) 15%,var(--card)),color-mix(in srgb,var(--b) 8%,var(--card)))',
            border: '1px solid var(--border)', position: 'relative', overflow: 'hidden',
            display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div style={{ position: 'absolute', inset: 0,
              backgroundImage: `linear-gradient(color-mix(in srgb,var(--a) 8%,transparent) 1px,transparent 1px),linear-gradient(90deg,color-mix(in srgb,var(--a) 8%,transparent) 1px,transparent 1px)`,
              backgroundSize: '32px 32px' }} />
            <div style={{ position: 'relative', zIndex: 1, textAlign: 'center' }}>
              <div style={{ width: 100, height: 100, borderRadius: '50%',
                background: 'linear-gradient(135deg,var(--a),var(--c))',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 42, margin: '0 auto 16px' }}>✦</div>
              <div style={{ fontFamily: 'var(--ff)', fontSize: 20, fontWeight: 700 }}>Your Name</div>
              <div style={{ fontSize: 13, color: 'var(--muted)', marginTop: 4 }}>
                Senior Frontend Engineer & Designer
              </div>
            </div>
          </div>
        </div>

        {/* Values */}
        <div style={{ marginBottom: 96 }}>
          <div style={{ fontSize: 10, letterSpacing: '2.5px', textTransform: 'uppercase',
            color: 'var(--a2)', marginBottom: 18, display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ width: 18, height: 1, background: 'var(--a2)' }} />
            Values
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 20 }}>
            {[
              { icon: '⚡', title: 'Craft first', body: 'Every detail matters. I obsess over the things most people miss — timing curves, shadow depths, type sizing at every breakpoint.' },
              { icon: '🚀', title: 'Performance always', body: 'Beautiful and fast aren\'t trade-offs. I write code that scores 95+ on Lighthouse without sacrificing visual quality.' },
              { icon: '🤝', title: 'Partnership over service', body: 'I\'m most effective as a partner in the product process, not just an executor of specs. I ask why before asking how.' },
            ].map(v => (
              <div key={v.title} style={{ background: 'var(--card)', border: '1px solid var(--border)',
                borderRadius: 22, padding: 36 }}>
                <span style={{ fontSize: 32, marginBottom: 18, display: 'block' }}>{v.icon}</span>
                <div style={{ fontFamily: 'var(--ff)', fontSize: 18, fontWeight: 700,
                  letterSpacing: '-.3px', marginBottom: 12 }}>{v.title}</div>
                <p style={{ fontSize: 14, color: 'var(--muted)', lineHeight: 1.7 }}>{v.body}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Stack */}
        <div>
          <div style={{ fontSize: 10, letterSpacing: '2.5px', textTransform: 'uppercase',
            color: 'var(--a2)', marginBottom: 18, display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ width: 18, height: 1, background: 'var(--a2)' }} />
            Current Stack
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12 }}>
            {['Next.js 15','React 19','TypeScript','Tailwind v4','Framer Motion','GSAP',
              'Three.js / R3F','Figma','Node.js','PostgreSQL','Prisma','Vercel',
              'Shadcn UI','Radix UI','Lenis','Zod'].map(t => (
              <span key={t} style={{ background: 'var(--card)', border: '1px solid var(--border)',
                borderRadius: 100, padding: '8px 18px', fontSize: 13, color: 'var(--muted)',
                fontFamily: 'var(--fm)' }}>{t}</span>
            ))}
          </div>
        </div>
      </div>
    </main>
  )
}
