import { NextResponse } from 'next/server'

interface ContactPayload {
  firstName: string
  lastName: string
  email: string
  budget: string
  projectType: string
  message: string
}

export async function POST(req: Request) {
  try {
    const body: ContactPayload = await req.json()

    // Validate required fields
    if (!body.email || !body.firstName || !body.message) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(body.email)) {
      return NextResponse.json({ error: 'Invalid email address' }, { status: 400 })
    }

    // Send via Resend (requires RESEND_API_KEY env var)
    if (process.env.RESEND_API_KEY) {
      const { Resend } = await import('resend')
      const resend = new Resend(process.env.RESEND_API_KEY)

      await resend.emails.send({
        from: process.env.RESEND_FROM_EMAIL ?? 'onboarding@resend.dev', // Replace with your verified Resend domain
        to: process.env.CONTACT_EMAIL ?? 'hello@your-domain.com',
        subject: `New project enquiry from ${body.firstName} ${body.lastName}`,
        html: `
          <h2>New Project Enquiry</h2>
          <p><strong>Name:</strong> ${body.firstName} ${body.lastName}</p>
          <p><strong>Email:</strong> ${body.email}</p>
          <p><strong>Budget:</strong> ${body.budget}</p>
          <p><strong>Project Type:</strong> ${body.projectType}</p>
          <hr />
          <p>${body.message}</p>
        `,
        replyTo: body.email,
      })
    }

    return NextResponse.json({ success: true })
  } catch (err) {
    console.error('[Contact API]', err)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
