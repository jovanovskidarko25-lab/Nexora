import type { Metadata } from 'next'
import { Contact } from '@/sections'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'

export const metadata: Metadata = {
  title: 'Contact',
  description: 'Start a project or just say hello.',
}

export default function ContactPage() {
  return (
    <main style={{ paddingTop: 120 }}>
      <div style={{ padding: '0 52px 0', maxWidth: 1280, margin: '0 auto' }}>
        <div style={{ maxWidth: 600, marginBottom: 64 }}>
          <div style={{ fontSize: 10, letterSpacing: '2.5px', textTransform: 'uppercase',
            color: 'var(--a2)', marginBottom: 18, display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ width: 18, height: 1, background: 'var(--a2)' }} />
            Get In Touch
          </div>
          <h1 style={{ fontFamily: 'var(--ff)', fontSize: 'clamp(40px,6vw,72px)',
            fontWeight: 800, letterSpacing: '-3px', lineHeight: 1.0, marginBottom: 20 }}>
            Let&apos;s build<br />
            <span style={{ background: 'linear-gradient(135deg,var(--a2),var(--b2))',
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              something great.
            </span>
          </h1>
          <p style={{ fontSize: 17, color: 'var(--muted)', lineHeight: 1.75, fontWeight: 300 }}>
            Have a project in mind? Fill in the form or reach out directly. I respond within 24 hours.
          </p>
        </div>
      </div>
      <Contact />
      <Footer />
    </main>
  )
}
