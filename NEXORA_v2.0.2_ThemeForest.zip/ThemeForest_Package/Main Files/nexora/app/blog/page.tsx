import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Blog',
  description: 'Insights on design, animation, and frontend engineering.',
}

const POSTS = [
  { slug: 'framer-motion-advanced', title: 'Advanced Framer Motion Patterns for 2026', date: 'Jan 12, 2026', category: 'Animation', readTime: '8 min', excerpt: 'Deep dive into orchestration, shared layout animations, and performance optimization techniques that separate good animations from great ones.' },
  { slug: 'nextjs-16-performance', title: 'Next.js 15 Performance: The Complete Guide', date: 'Dec 28, 2025', category: 'Engineering', readTime: '12 min', excerpt: 'Everything you need to know about React Server Components, partial pre-rendering, and Turbopack to ship blazing fast applications.' },
  { slug: 'design-tokens-at-scale', title: 'Design Tokens at Scale: Lessons from 50+ Projects', date: 'Dec 14, 2025', category: 'Design Systems', readTime: '10 min', excerpt: 'How to structure a token architecture that supports multiple brands, themes, and component states without collapsing into chaos.' },
  { slug: 'gsap-scrolltrigger-mastery', title: 'GSAP ScrollTrigger Mastery', date: 'Nov 30, 2025', category: 'Animation', readTime: '15 min', excerpt: 'Pin sections, scrub timelines, and create cinematic scroll experiences. A comprehensive guide to the most powerful scroll animation tool.' },
  { slug: 'tailwind-v4-migration', title: 'Migrating to Tailwind CSS v4', date: 'Nov 18, 2025', category: 'CSS', readTime: '7 min', excerpt: 'The new CSS-first configuration, lightning-fast engine, and breaking changes you need to know before upgrading your project.' },
  { slug: 'webgl-three-js-2026', title: 'WebGL & Three.js in 2026: What Changed', date: 'Nov 5, 2025', category: '3D / WebGL', readTime: '11 min', excerpt: 'WebGPU adoption, React Three Fiber 9, and the new patterns redefining what\'s possible in browser-based 3D graphics.' },
]

export default function BlogPage() {
  return (
    <main style={{ paddingTop: 120 }}>
      <div style={{ padding: '0 52px 96px', maxWidth: 1280, margin: '0 auto' }}>
        {/* Header */}
        <div style={{ marginBottom: 64 }}>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontSize: 10,
            letterSpacing: '2.5px', textTransform: 'uppercase', color: 'var(--a2)', marginBottom: 18 }}>
            <span style={{ width: 18, height: 1, background: 'var(--a2)' }} />
            Writing
          </div>
          <h1 style={{ fontFamily: 'var(--ff)', fontSize: 'clamp(40px,6vw,72px)',
            fontWeight: 800, letterSpacing: '-3px', lineHeight: 1.0, marginBottom: 16 }}>
            Thoughts on craft
          </h1>
          <p style={{ fontSize: 17, color: 'var(--muted)', maxWidth: 460, fontWeight: 300, lineHeight: 1.75 }}>
            Monthly essays on design systems, animation engineering, and building premium digital products.
          </p>
        </div>

        {/* Posts grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 20 }}>
          {POSTS.map((post, i) => (
            <a key={post.slug} href={`/blog/${post.slug}`}
              style={{ textDecoration: 'none', background: 'var(--card)',
                border: '1px solid var(--border)', borderRadius: 22, overflow: 'hidden',
                transition: 'all .3s', cursor: 'pointer', display: 'block' }}>
              {/* Thumbnail */}
              <div style={{ height: 180, background: 'var(--card2)', position: 'relative',
                overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <div style={{ position: 'absolute', inset: 0,
                  backgroundImage: `linear-gradient(color-mix(in srgb,var(--a) ${8 + i * 2}%,transparent) 1px,transparent 1px),linear-gradient(90deg,color-mix(in srgb,var(--a) ${8 + i * 2}%,transparent) 1px,transparent 1px)`,
                  backgroundSize: '24px 24px' }} />
                <span style={{ position: 'relative', zIndex: 1,
                  background: 'color-mix(in srgb,var(--a) 12%,transparent)',
                  border: '1px solid color-mix(in srgb,var(--a) 20%,transparent)',
                  borderRadius: 100, padding: '6px 14px', fontSize: 11,
                  color: 'var(--a2)', fontWeight: 500 }}>{post.category}</span>
              </div>
              {/* Body */}
              <div style={{ padding: 28 }}>
                <div style={{ display: 'flex', gap: 12, marginBottom: 14,
                  fontSize: 11, color: 'var(--muted2)' }}>
                  <span>{post.date}</span>
                  <span>·</span>
                  <span>{post.readTime} read</span>
                </div>
                <h2 style={{ fontFamily: 'var(--ff)', fontSize: 17, fontWeight: 700,
                  letterSpacing: '-.4px', lineHeight: 1.3, marginBottom: 10,
                  color: 'var(--text)' }}>{post.title}</h2>
                <p style={{ fontSize: 13, color: 'var(--muted)', lineHeight: 1.65 }}>{post.excerpt}</p>
                <div style={{ marginTop: 20, fontSize: 12, color: 'var(--a2)', fontWeight: 500 }}>
                  Read article →
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </main>
  )
}
