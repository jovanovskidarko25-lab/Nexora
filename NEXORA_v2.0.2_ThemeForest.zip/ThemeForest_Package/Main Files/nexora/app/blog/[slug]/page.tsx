import type { Metadata } from 'next'
import { notFound } from 'next/navigation'

interface Props { params: Promise<{ slug: string }> }

const POSTS = [
  { slug: 'framer-motion-advanced', title: 'Advanced Framer Motion Patterns' },
  { slug: 'nextjs-16-performance', title: 'Next.js 15 Performance: The Complete Guide' },
  { slug: 'design-tokens-at-scale', title: 'Design Tokens at Scale' },
  { slug: 'gsap-scrolltrigger-mastery', title: 'GSAP ScrollTrigger Mastery' },
  { slug: 'tailwind-v4-migration', title: 'Migrating to Tailwind CSS v4' },
  { slug: 'webgl-three-js-2026', title: 'WebGL & Three.js in 2026' },
]

export async function generateStaticParams() {
  return POSTS.map(p => ({ slug: p.slug }))
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params
  const post = POSTS.find(p => p.slug === slug)
  if (!post) return {}
  return { title: post.title }
}

export default async function BlogPostPage({ params }: Props) {
  const { slug } = await params
  const post = POSTS.find(p => p.slug === slug)
  if (!post) notFound()

  return (
    <main style={{ paddingTop: 120, minHeight: '100vh' }}>
      <div style={{ padding: '0 52px 96px', maxWidth: 780, margin: '0 auto' }}>
        <h1 style={{ fontFamily: 'var(--ff)', fontSize: 'clamp(32px,5vw,56px)',
          fontWeight: 800, letterSpacing: '-2px', lineHeight: 1.05, marginBottom: 24 }}>
          {post.title}
        </h1>
        <p style={{ fontSize: 15, color: 'var(--muted)', lineHeight: 1.8 }}>
          Replace this with your blog content. You can connect a CMS — see /docs/cms-setup.md.
        </p>
      </div>
    </main>
  )
}
