'use client'

import { useState, useCallback } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import DemoSwitcher from '@/components/shared/DemoSwitcher'
import DemosGrid from '@/components/shared/DemosGrid'
import { HERO_MAP } from '@/sections/Hero'
import {
  Ticker, StatsBar, BentoGrid, Services, About,
  Timeline, Testimonials, Awards, Pricing, FAQ, Contact, Newsletter,
} from '@/sections'
import type { DemoId } from '@/constants/demos'
import { DEMOS } from '@/constants/demos'

export default function HomePage() {
  const [demo, setDemo] = useState<DemoId>('ai')
  const [transitioning, setTransitioning] = useState(false)

  const handleDemoChange = useCallback(
    (id: DemoId) => {
      if (id === demo || transitioning) return
      setTransitioning(true)
      setTimeout(() => {
        setDemo(id)
        Object.values(DEMOS).forEach(d => {
          if (d.themeClass) document.body.classList.remove(d.themeClass)
        })
        if (DEMOS[id].themeClass) document.body.classList.add(DEMOS[id].themeClass)
        window.scrollTo({ top: 0, behavior: 'smooth' })
        setTransitioning(false)
      }, 450)
    },
    [demo, transitioning]
  )

  const HeroComponent = HERO_MAP[demo]

  return (
    <>
      <Navbar />
      {/* #main-content target for skip-link */}
      <span id="main-content" tabIndex={-1} style={{ position: 'absolute', top: 0 }} aria-hidden="true" />


      <AnimatePresence>
        {transitioning && (
          <motion.div
            key="wipe"
            initial={{ clipPath: 'inset(100% 0 0 0)' }}
            animate={{ clipPath: 'inset(0% 0 0 0)' }}
            exit={{ clipPath: 'inset(0 0 100% 0)' }}
            transition={{ duration: 0.45, ease: [0.76, 0, 0.24, 1] }}
            aria-hidden="true"
            style={{ position: 'fixed', inset: 0, background: 'var(--card)', zIndex: 3000, pointerEvents: 'none' }}
          />
        )}
      </AnimatePresence>

      <AnimatePresence mode="wait">
        <motion.div key={demo} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.3 }}>
          <HeroComponent />
        </motion.div>
      </AnimatePresence>

      <Ticker />
      <StatsBar />

      <section id="demos" style={{ padding: '96px 52px', maxWidth: 1380, margin: '0 auto' }}>
        <DemosGrid activeDemo={demo} onSelect={handleDemoChange} />
      </section>

      <BentoGrid />
      <Services />
      <About />
      <Timeline />
      <Testimonials />
      <Awards />
      <Pricing />
      <FAQ />
      <Contact />
      <Newsletter />
      <Footer />

      <DemoSwitcher activeDemo={demo} onChange={handleDemoChange} />
    </>
  )
}
