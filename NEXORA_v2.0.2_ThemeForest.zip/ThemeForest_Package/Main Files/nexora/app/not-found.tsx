import Navbar from '@/components/layout/Navbar'

export default function NotFound() {
  return (
    <>
      <Navbar />
      <main style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', textAlign: 'center',
        padding: '0 52px', position: 'relative', overflow: 'hidden' }}>
      {/* Bg orb */}
      <div style={{ position: 'absolute', width: 500, height: 500, borderRadius: '50%',
        background: 'radial-gradient(circle,var(--ga),transparent 65%)',
        top: '50%', left: '50%', transform: 'translate(-50%,-50%)',
        pointerEvents: 'none' }} />

      <div style={{ position: 'relative', zIndex: 1 }}>
        <div style={{ fontFamily: 'var(--fm)', fontSize: 11, color: 'var(--a2)',
          letterSpacing: '3px', textTransform: 'uppercase', marginBottom: 20 }}>
          Error 404
        </div>
        <h1 style={{ fontFamily: 'var(--ff)', fontSize: 'clamp(80px,15vw,180px)',
          fontWeight: 800, letterSpacing: '-8px', lineHeight: 1,
          background: 'linear-gradient(135deg,var(--text),var(--muted2))',
          WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', marginBottom: 24 }}>
          404
        </h1>
        <p style={{ fontSize: 17, color: 'var(--muted)', maxWidth: 400,
          margin: '0 auto 40px', fontWeight: 300, lineHeight: 1.7 }}>
          This page has drifted into the void. Let's get you back to solid ground.
        </p>
        <a href="/" style={{ display: 'inline-flex', alignItems: 'center', gap: 8,
          background: 'linear-gradient(135deg,var(--a),var(--c))', color: '#fff',
          padding: '13px 30px', borderRadius: 100, fontSize: 14, fontWeight: 600,
          textDecoration: 'none',
          boxShadow: '0 4px 20px color-mix(in srgb,var(--a) 35%,transparent)' }}>
          ← Back to Home
        </a>
      </div>
    </main>
    </>
  )
}
