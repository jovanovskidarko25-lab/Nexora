// types/index.ts
// NEXORA — Shared TypeScript types

export type { DemoId, Demo } from '@/constants/demos'

export interface BlogPost {
  slug: string
  title: string
  date: string
  category: string
  readTime: string
  excerpt: string
  content?: string
}

export interface NavLink {
  label: string
  href: string
  external?: boolean
}

export interface SocialLink {
  platform: string
  url: string
  icon: string
}
