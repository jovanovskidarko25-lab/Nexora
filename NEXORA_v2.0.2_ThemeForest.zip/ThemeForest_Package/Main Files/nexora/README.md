 NEXORA — Ultra Premium Portfolio Template

**8 homepage demos · 20+ sections · Next.js 15 · TypeScript · Framer Motion · GSAP**

---

## Quick Start

```bash
# 1. Install dependencies
npm install          # or: pnpm install / yarn

# 2. Copy environment variables
cp .env.local.example .env.local
# Then edit .env.local with your values

# 3. Start the dev server
npm run dev

# 4. Open in browser
open http://localhost:3000
```

Requirements: **Node.js 20+**

---

## Demos

| Demo ID | Name | Accent |
|---------|------|--------|
| `ai` | AI Engineer | Purple / Cyan |
| `creative` | Creative Developer | Rose / Orange |
| `cyber` | Cybersecurity | Matrix Green |
| `luxury` | Luxury Minimal | Gold / Navy |
| `motion` | Motion Designer | Violet / Fuchsia |
| `agency` | Agency | Bold Monochrome |
| `freelancer` | Freelancer | Amber / Red |
| `3d` | Interactive 3D | Indigo / Cyan |

Switch demos at runtime with the pill bar at the bottom of the page, or set a
fixed demo in `app/page.tsx`.

---

## Project Structure

```
nexora/
├── app/                  # Next.js App Router pages & API routes
├── components/
│   ├── layout/           # Navbar, Footer
│   └── shared/           # CustomCursor, DemoSwitcher, SmoothScroll, PageTransition
├── sections/
│   ├── Hero/             # 8 hero variants
│   └── index.tsx         # All 20+ sections (Ticker, BentoGrid, FAQ, Contact …)
├── hooks/                # useScrollReveal, useCountUp, useMediaQuery, useTheme …
├── lib/                  # animations.ts, utils.ts
├── constants/            # Demos, projects, services, pricing data
├── styles/               # tokens.css — all 8 themes
├── docs/                 # cms-setup.md
├── public/               # fonts, images, og
├── .env.local.example
├── CHANGELOG.md
├── DOCUMENTATION.md      # Full reference guide
└── LICENSE.txt
```

---

## Customisation

### Change accent colours

All colours are CSS custom properties in `styles/tokens.css`:

```css
:root {
  --a:  #8b5cf6;   /* primary accent */
  --a2: #a78bfa;   /* primary light  */
  --b:  #22d3ee;   /* secondary      */
  --c:  #3b82f6;   /* tertiary       */
}
```

### Add a new theme

1. Add a new class block in `styles/tokens.css` following the existing pattern.
2. Register it in `constants/demos.ts`.
3. Add its `themeClass` to `hooks/index.ts` → `THEME_CLASSES`.

### Connect a CMS

See `docs/cms-setup.md` for Sanity, Contentful, and Notion guides.

---

## Build & Deploy

```bash
npm run build    # production build
npm run start    # production server

# Deploy to Vercel (recommended):
npx vercel --prod
```

---

## Support

supporttemplyt@gmail.com

---

## License

See `LICENSE.txt`. Regular License = one end product. Extended License = multiple or sold products.
