import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './app/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './sections/**/*.{ts,tsx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        display: ['var(--ff)', 'sans-serif'],
        body:    ['var(--fb)', 'sans-serif'],
        mono:    ['var(--fm)', 'monospace'],
        serif:   ['var(--fs)', 'serif'],
      },
      // Compact typography scale — 2026 SaaS premium style
      fontSize: {
        'xs':   ['11px', { lineHeight: '1.45' }],
        'sm':   ['12px', { lineHeight: '1.5'  }],
        'base': ['13px', { lineHeight: '1.55' }],
        'lg':   ['15px', { lineHeight: '1.5'  }],
        'xl':   ['18px', { lineHeight: '1.4'  }],
        '2xl':  ['22px', { lineHeight: '1.3'  }],
        '3xl':  ['28px', { lineHeight: '1.2'  }],
        '4xl':  ['34px', { lineHeight: '1.15' }],
        '5xl':  ['42px', { lineHeight: '1.1'  }],
        '6xl':  ['52px', { lineHeight: '1.05' }],
        '7xl':  ['64px', { lineHeight: '1.0'  }],
      },
      spacing: {
        // Slightly tighter spacing for compact premium feel
        '18': '4.25rem',
        '22': '5.25rem',
      },
    },
  },
  plugins: [],
}

export default config
