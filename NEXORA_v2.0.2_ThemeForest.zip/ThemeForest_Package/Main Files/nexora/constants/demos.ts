// constants/demos.ts
// NEXORA — Demo configuration

export type DemoId =
  | 'ai'
  | 'creative'
  | 'cyber'
  | 'luxury'
  | 'motion'
  | 'agency'
  | 'freelancer'
  | '3d'

export interface Demo {
  id: DemoId
  name: string
  description: string
  themeClass: string
  badge: string
  headline: string
  subheadline: string
  primaryCta: string
  secondaryCta: string
  accentColor: string
  fontDisplay: string
  tags: string[]
}

export const DEMOS: Record<DemoId, Demo> = {
  ai: {
    id: 'ai',
    name: 'AI Engineer',
    description: 'Purple & cyan dark luxury for ML engineers and AI researchers',
    themeClass: '',
    badge: '⚡ Available for Freelance — 2026',
    headline: 'Design that moves.\nCode that scales.',
    subheadline:
      'Full-stack creative engineer crafting premium digital experiences at the intersection of design and technology.',
    primaryCta: 'View My Work',
    secondaryCta: 'Get In Touch',
    accentColor: '#8b5cf6',
    fontDisplay: 'Syne',
    tags: ['Next.js', 'React', 'TypeScript', 'Framer Motion'],
  },
  creative: {
    id: 'creative',
    name: 'Creative Developer',
    description: 'Vibrant rose & orange palette for creative developers',
    themeClass: 't-creative',
    badge: '🎨 Creative Developer — Open to Work',
    headline: 'I craft interfaces\nthat feel alive.',
    subheadline:
      'UI engineer and visual designer obsessed with micro-interactions, motion systems, and bold digital aesthetics.',
    primaryCta: 'See My Projects',
    secondaryCta: 'Say Hello',
    accentColor: '#f43f5e',
    fontDisplay: 'Space Grotesk',
    tags: ['React', 'Figma', 'Framer', 'Animation'],
  },
  cyber: {
    id: 'cyber',
    name: 'Cybersecurity',
    description: 'Matrix green terminal aesthetic for security specialists',
    themeClass: 't-cyber',
    badge: '🔐 Security Engineer · Remote · Open to Work',
    headline: 'Breaking systems.\nBuilding resilience.',
    subheadline:
      'Cybersecurity specialist with 8+ years in penetration testing, red teaming, and secure architecture.',
    primaryCta: 'View Case Studies',
    secondaryCta: 'Hire Me',
    accentColor: '#00ff88',
    fontDisplay: 'JetBrains Mono',
    tags: ['Pentesting', 'Red Team', 'SIEM', 'Zero Trust'],
  },
  luxury: {
    id: 'luxury',
    name: 'Luxury Minimal',
    description: 'Gold & deep navy for premium consultants and high-end services',
    themeClass: 't-luxury',
    badge: '✦ Premium Creative Services · Est. 2017',
    headline: 'Artistry.\nPrecision. Vision.',
    subheadline:
      'High-end digital experiences for luxury brands, premium consultancies, and clients who demand excellence.',
    primaryCta: 'View Portfolio',
    secondaryCta: 'Enquire Now',
    accentColor: '#c9a84c',
    fontDisplay: 'Playfair Display',
    tags: ['Luxury', 'Branding', 'Strategy', 'Web'],
  },
  motion: {
    id: 'motion',
    name: 'Motion Designer',
    description: 'Cinema-inspired violet palette celebrating movement and craft',
    themeClass: 't-motion',
    badge: '🎬 Motion Designer & Art Director',
    headline: 'Motion is\nthe language of emotion.',
    subheadline:
      'Award-winning motion designer crafting cinematic digital experiences for brands, films, and platforms.',
    primaryCta: 'Watch Showreel',
    secondaryCta: 'Book a Call',
    accentColor: '#a855f7',
    fontDisplay: 'Syne',
    tags: ['After Effects', 'Cinema 4D', 'GSAP', 'WebGL'],
  },
  agency: {
    id: 'agency',
    name: 'Agency Portfolio',
    description: 'Bold and confident layout for digital agencies and studios',
    themeClass: 't-agency',
    badge: '🏢 Full-Service Digital Agency · Berlin',
    headline: 'We make brands\nunforgettable.',
    subheadline:
      'A boutique digital agency specialising in brand identity, web experience, and campaigns.',
    primaryCta: 'See Our Work',
    secondaryCta: 'Start a Project',
    accentColor: '#ffffff',
    fontDisplay: 'Space Grotesk',
    tags: ['Branding', 'Web', 'Strategy', 'Campaigns'],
  },
  freelancer: {
    id: 'freelancer',
    name: 'Freelancer',
    description: 'Conversion-optimised layout focused on trust and quick action',
    themeClass: 't-freelancer',
    badge: '⚡ Available Now · Fast Delivery · Fixed Rates',
    headline: 'Your vision.\nMy expertise.',
    subheadline:
      'Experienced freelance designer and developer specialising in high-converting websites and SaaS interfaces.',
    primaryCta: 'Browse Packages',
    secondaryCta: 'Get Free Quote',
    accentColor: '#f59e0b',
    fontDisplay: 'Space Grotesk',
    tags: ['Webflow', 'React', 'Shopify', 'WordPress'],
  },
  '3d': {
    id: '3d',
    name: 'Interactive 3D',
    description: 'Three.js powered hero with particle depth system',
    themeClass: 't-3d',
    badge: '🌐 3D Designer & WebGL Developer',
    headline: 'Enter the\nthird dimension.',
    subheadline:
      'WebGL artist and Three.js developer creating immersive 3D web experiences and real-time visualisations.',
    primaryCta: 'Explore 3D Work',
    secondaryCta: 'Commission Work',
    accentColor: '#6366f1',
    fontDisplay: 'Space Grotesk',
    tags: ['Three.js', 'R3F', 'GLSL', 'WebGPU'],
  },
}
