// constants/index.ts
// NEXORA — All data exports

export { DEMOS } from './demos'
export type { DemoId, Demo } from './demos'

// ─── PROJECTS ───────────────────────────────────────────────────
export interface Project {
  id: string
  title: string
  category: string
  description: string
  tags: string[]
  span: 'large' | 'medium-tall' | 'medium' | 'small'
  metric?: { value: string; label: string }
  year: string
  link?: string
}

export const PROJECTS: Project[] = [
  {
    id: 'lumina',
    title: 'Lumina — AI Design System',
    category: 'Featured Project',
    description:
      'Next-gen design system for AI-first products. 240+ components, full dark/light themes, Figma integration.',
    tags: ['Next.js 15', 'TypeScript', 'Figma API', 'Storybook'],
    span: 'large',
    year: '2025',
  },
  {
    id: 'axiom',
    title: 'Axiom Analytics',
    category: 'SaaS Platform',
    description: 'Data analytics dashboard redesign that boosted engagement 340%.',
    tags: ['React', 'D3.js'],
    span: 'medium-tall',
    metric: { value: '+340%', label: 'User engagement post-redesign' },
    year: '2024',
  },
  {
    id: 'flux',
    title: 'Flux Store',
    category: 'E-Commerce',
    description: 'Premium e-commerce platform with cinematic product reveals.',
    tags: ['Next.js', 'Shopify'],
    span: 'medium-tall',
    metric: { value: '$2.4M', label: 'Revenue generated year one' },
    year: '2024',
  },
  {
    id: 'motion-kit',
    title: 'Motion Kit',
    category: 'Open Source',
    description: 'Framer Motion utilities library. 4,200+ GitHub stars.',
    tags: ['TypeScript', 'Framer Motion'],
    span: 'small',
    year: '2023',
  },
  {
    id: 'nebula',
    title: 'Nebula Agency',
    category: 'Award Winning',
    description: 'Awwwards SOTD. FWA. 99 PageSpeed.',
    tags: ['Next.js', 'GSAP', 'R3F'],
    span: 'small',
    year: '2024',
  },
  {
    id: 'pulse',
    title: 'Pulse Health',
    category: 'Mobile App',
    description: 'React Native app. 80k+ DAU. App Store featured.',
    tags: ['React Native', 'Expo'],
    span: 'small',
    year: '2024',
  },
]

// ─── SERVICES ───────────────────────────────────────────────────
export const SERVICES = [
  {
    num: '01',
    title: 'Product Design',
    description:
      'End-to-end design from research and wireframing to pixel-perfect Figma deliverables. Design systems, component libraries, interactive prototypes.',
  },
  {
    num: '02',
    title: 'Frontend Engineering',
    description:
      'High-performance React & Next.js in TypeScript. Animation-rich interfaces, smooth page transitions, 95+ Lighthouse scores consistently.',
  },
  {
    num: '03',
    title: 'Creative Direction',
    description:
      'Brand identity systems, visual storytelling, and digital campaigns that transform vision into cohesive visual languages.',
  },
  {
    num: '04',
    title: 'Motion & Animation',
    description:
      'GSAP and Framer Motion powered experiences. Scroll reveals, SVG animations, 3D with Three.js, cinematic transitions.',
  },
  {
    num: '05',
    title: 'Full-Stack Development',
    description:
      'Complete web apps with Node.js, PostgreSQL, REST/GraphQL APIs, auth systems, and Vercel or AWS deployment.',
  },
  {
    num: '06',
    title: 'Consulting & Audit',
    description:
      'Performance audits, UX reviews, accessibility assessments, and technical consulting for growing product teams.',
  },
]

// ─── PRICING ────────────────────────────────────────────────────
export const PRICING = [
  {
    name: 'Starter',
    price: '$2,400',
    period: 'one-time · 2 week delivery',
    featured: false,
    features: [
      { label: 'Custom landing page',  included: true },
      { label: 'Mobile responsive',    included: true },
      { label: '3 content sections',   included: true },
      { label: 'Basic animations',     included: true },
      { label: 'Component library',    included: false },
      { label: 'Full source files',    included: false },
    ],
    cta: 'Get Started',
  },
  {
    name: 'Professional',
    price: '$6,800',
    period: 'one-time · 4 week delivery',
    featured: true,
    features: [
      { label: 'Full site up to 8 pages', included: true },
      { label: 'Premium animations',      included: true },
      { label: 'Design system',           included: true },
      { label: 'CMS integration',         included: true },
      { label: 'Component library',       included: true },
      { label: 'Full source files',       included: true },
    ],
    cta: 'Get Started',
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    period: 'retainer or project · flexible',
    featured: false,
    features: [
      { label: 'Unlimited scope',    included: true },
      { label: 'Dedicated support',  included: true },
      { label: 'Team onboarding',    included: true },
      { label: 'Performance SLA',    included: true },
      { label: 'Monthly retainer',   included: true },
      { label: 'White-label rights', included: true },
    ],
    cta: 'Contact Me',
  },
]

// ─── NAVIGATION ─────────────────────────────────────────────────
export const NAV_LINKS = [
  { label: 'Demos',    href: '#demos' },
  { label: 'Work',     href: '#work' },
  { label: 'Services', href: '#services' },
  { label: 'About',    href: '#about' },
  { label: 'Pricing',  href: '#pricing' },
  { label: 'Contact',  href: '#contact' },
]
