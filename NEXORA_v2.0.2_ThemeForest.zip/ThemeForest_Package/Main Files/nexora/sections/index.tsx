// sections/index.tsx
// NEXORA — All 20+ section components
// Production-ready React/TypeScript components with Framer Motion animations

'use client'

import React, { useRef, useState } from 'react'
import { motion, useInView, AnimatePresence } from 'framer-motion'
import { fadeUp, fadeLeft, fadeRight, scaleIn, staggerContainer, staggerFade, blurIn } from '@/lib/animations'
import { PROJECTS, SERVICES, PRICING } from '@/constants'

// ═══════════════════════════════════════════════════════════════
// SECTION WRAPPER
// ═══════════════════════════════════════════════════════════════
interface SectionProps {
  children: React.ReactNode
  id?: string
  className?: string
  dark?: boolean
}

export function Section({ children, id, className = '', dark }: SectionProps) {
  return (
    <section
      id={id}
      className={`relative ${dark ? 'bg-[var(--deep)]' : ''} ${className}`}
      style={{ padding: '96px 52px', maxWidth: '1380px', margin: '0 auto' }}
    >
      {children}
    </section>
  )
}

// ═══════════════════════════════════════════════════════════════
// SECTION TAG + HEADLINE
// ═══════════════════════════════════════════════════════════════
export function SectionHeader({
  tag, title, subtitle, align = 'left'
}: {
  tag: string; title: React.ReactNode; subtitle?: string; align?: 'left' | 'center'
}) {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, amount: 0.2 })

  return (
    <div ref={ref} style={{ textAlign: align, marginBottom: '52px' }}>
      <motion.div
        variants={fadeUp} initial="hidden" animate={inView ? 'show' : 'hidden'}
        style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontSize: 10,
          letterSpacing: '2.5px', textTransform: 'uppercase', color: 'var(--a2)',
          marginBottom: 18 }}
      >
        <span style={{ width: 18, height: 1, background: 'var(--a2)', display: 'block' }} />
        {tag}
      </motion.div>
      <motion.h2
        variants={fadeUp} initial="hidden" animate={inView ? 'show' : 'hidden'}
        transition={{ delay: 0.08 }}
        style={{ fontFamily: 'var(--ff)', fontSize: 'clamp(32px,5vw,56px)',
          fontWeight: 800, lineHeight: 1.05, letterSpacing: '-2px', marginBottom: 14 }}
      >
        {title}
      </motion.h2>
      {subtitle && (
        <motion.p
          variants={fadeUp} initial="hidden" animate={inView ? 'show' : 'hidden'}
          transition={{ delay: 0.16 }}
          style={{ fontSize: 16, color: 'var(--muted)', lineHeight: 1.75,
            fontWeight: 300, maxWidth: 460 }}
        >
          {subtitle}
        </motion.p>
      )}
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
// 1. TICKER / MARQUEE
// ═══════════════════════════════════════════════════════════════
const TECHS = ['Next.js 15','React 19','TypeScript','Framer Motion','Tailwind v4',
  'GSAP','Three.js / R3F','Figma','Node.js','Prisma ORM','PostgreSQL',
  'Vercel','Shadcn UI','Lenis Scroll','Zod','Turborepo']

export function Ticker() {
  const items = [...TECHS, ...TECHS]
  return (
    <div style={{ overflow: 'hidden', borderTop: '1px solid var(--border)',
      borderBottom: '1px solid var(--border)', padding: '15px 0', position: 'relative' }}>
      <div style={{ position: 'absolute', top: 0, bottom: 0, left: 0, width: 100,
        background: 'linear-gradient(to right, var(--bg), transparent)', zIndex: 2 }} />
      <div style={{ position: 'absolute', top: 0, bottom: 0, right: 0, width: 100,
        background: 'linear-gradient(to left, var(--bg), transparent)', zIndex: 2 }} />
      <motion.div
        style={{ display: 'flex', gap: 48, width: 'max-content', whiteSpace: 'nowrap' }}
        animate={{ x: '-50%' }}
        transition={{ duration: 28, repeat: Infinity, ease: 'linear' }}
      >
        {items.map((t, i) => (
          <span key={i} style={{ display: 'inline-flex', alignItems: 'center', gap: 10,
            fontSize: 11, fontWeight: 500, color: 'var(--muted2)',
            letterSpacing: '1.2px', textTransform: 'uppercase' }}>
            <span style={{ width: 3, height: 3, borderRadius: '50%',
              background: 'var(--a)', flexShrink: 0 }} />
            {t}
          </span>
        ))}
      </motion.div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
// 2. STATS BAR
// ═══════════════════════════════════════════════════════════════
const STATS = [
  { value: 120, label: 'Projects Delivered', suffix: '+' },
  { value: 48,  label: 'Happy Clients',      suffix: '+' },
  { value: 8,   label: 'Years Experience',   suffix: '' },
  { value: 15,  label: 'Awards Won',         suffix: '+' },
]

export function StatsBar() {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, amount: 0.5 })
  const [counts, setCounts] = useState(STATS.map(() => 0))

  React.useEffect(() => {
    if (!inView) return
    STATS.forEach((stat, i) => {
      const duration = 1400
      const start = performance.now()
      const ease = (t: number) => 1 - Math.pow(1 - t, 4)
      const update = (now: number) => {
        const p = Math.min((now - start) / duration, 1)
        setCounts(c => { const n = [...c]; n[i] = Math.round(ease(p) * stat.value); return n })
        if (p < 1) requestAnimationFrame(update)
      }
      requestAnimationFrame(update)
    })
  }, [inView])

  return (
    <motion.div ref={ref} variants={scaleIn} initial="hidden"
      animate={inView ? 'show' : 'hidden'}
      style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)',
        borderBottom: '1px solid var(--border)', position: 'relative' }}>
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 1,
        background: 'linear-gradient(90deg,transparent,var(--a),transparent)' }} />
      {STATS.map((s, i) => (
        <div key={i} style={{ padding: '34px 40px', borderRight: i < 3 ? '1px solid var(--border)' : 'none',
          textAlign: 'center' }}>
          <div style={{ fontFamily: 'var(--ff)', fontSize: 42, fontWeight: 800, lineHeight: 1,
            background: 'linear-gradient(135deg,var(--text),var(--muted))',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
            {counts[i]}{s.suffix}
          </div>
          <div style={{ fontSize: 11, color: 'var(--muted2)', letterSpacing: '1.2px',
            textTransform: 'uppercase', marginTop: 6 }}>
            {s.label}
          </div>
        </div>
      ))}
    </motion.div>
  )
}

// ═══════════════════════════════════════════════════════════════
// 3. BENTO GRID (Selected Work)
// ═══════════════════════════════════════════════════════════════
export function BentoGrid() {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, amount: 0.1 })

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between',
        alignItems: 'flex-end', flexWrap: 'wrap', gap: 16, marginBottom: 52 }}>
        <SectionHeader tag="Selected Work" title={<>Projects that<br />define the craft</>} />
        <motion.button variants={fadeUp} initial="hidden" animate="show"
          whileHover={{ scale: 1.02 }}
          style={{ background: 'transparent', color: 'var(--text)', padding: '12px 24px',
            borderRadius: 100, fontSize: 13, fontWeight: 500, border: '1px solid var(--border2)',
            cursor: 'pointer', transition: 'all .3s' }}>
          View All Projects →
        </motion.button>
      </div>

      <motion.div ref={ref} variants={scaleIn} initial="hidden"
        animate={inView ? 'show' : 'hidden'}
        style={{ display: 'grid', gridTemplateColumns: 'repeat(12,1fr)', gap: 14 }}>

        {/* Large card */}
        <BentoCard span="7" rowSpan="2" style={{ minHeight: 360, padding: 36 }}>
          <div style={{ fontSize: 10, letterSpacing: '1.5px', textTransform: 'uppercase',
            color: 'var(--muted2)', marginBottom: 12 }}>Featured Project · 2025</div>
          <div style={{ fontFamily: 'var(--ff)', fontSize: 26, fontWeight: 800,
            letterSpacing: '-1px', marginBottom: 8 }}>Lumina — AI Design System</div>
          <div style={{ fontSize: 13, color: 'var(--muted)', lineHeight: 1.6 }}>
            Next-gen design system for AI-first products. 240+ components, full dark/light themes,
            Figma integration, and multi-brand token architecture.
          </div>
          <ProjectVisual />
          <div style={{ display: 'flex', gap: 8, marginTop: 16, flexWrap: 'wrap' }}>
            {['Next.js 15', 'TypeScript', 'Figma API', 'Storybook'].map(t => (
              <Pill key={t} variant={t === 'TypeScript' ? 'b' : t === 'Next.js 15' ? 'a' : 'c'}>{t}</Pill>
            ))}
          </div>
        </BentoCard>

        {/* Metric cards */}
        <BentoCard span="5" style={{ padding: 28, display: 'flex', flexDirection: 'column', justifyContent: 'space-between', minHeight: 176 }}>
          <div>
            <div style={{ fontSize: 10, letterSpacing: '1.5px', textTransform: 'uppercase', color: 'var(--muted2)', marginBottom: 8 }}>SaaS Platform</div>
            <div style={{ fontFamily: 'var(--ff)', fontSize: 17, fontWeight: 800 }}>Axiom Analytics</div>
          </div>
          <div>
            <div style={{ fontFamily: 'var(--ff)', fontSize: 44, fontWeight: 800, background: 'linear-gradient(135deg,var(--a2),var(--b2))', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', lineHeight: 1 }}>+340%</div>
            <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 4 }}>User engagement post-redesign</div>
          </div>
        </BentoCard>

        <BentoCard span="5" style={{ padding: 28, display: 'flex', flexDirection: 'column', justifyContent: 'space-between', minHeight: 176 }}>
          <div>
            <div style={{ fontSize: 10, letterSpacing: '1.5px', textTransform: 'uppercase', color: 'var(--muted2)', marginBottom: 8 }}>E-Commerce</div>
            <div style={{ fontFamily: 'var(--ff)', fontSize: 17, fontWeight: 800 }}>Flux Store</div>
          </div>
          <div>
            <div style={{ fontFamily: 'var(--ff)', fontSize: 44, fontWeight: 800, background: 'linear-gradient(135deg,var(--a2),var(--b2))', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', lineHeight: 1 }}>$2.4M</div>
            <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 4 }}>Revenue generated year one</div>
          </div>
        </BentoCard>

        {/* Small cards */}
        {[
          { cat: 'Open Source', title: 'Motion Kit', desc: 'Framer Motion utility library. 4,200+ ⭐ GitHub. Used by Vercel, Linear, Notion.' },
          { cat: 'Award Winning', title: 'Nebula Agency', desc: 'Awwwards SOTD. FWA. 99 PageSpeed. Webby Nominee 2024.', accent: true },
          { cat: 'Mobile App', title: 'Pulse Health', desc: 'React Native. 80k+ daily active users. App Store featured. 4.9★.' },
        ].map((p, i) => (
          <BentoCard key={i} span="4" style={{ padding: 28, minHeight: 186 }} accent={p.accent}>
            <div style={{ fontSize: 10, letterSpacing: '1.5px', textTransform: 'uppercase', color: 'var(--muted2)', marginBottom: 10 }}>{p.cat}</div>
            <div style={{ fontFamily: 'var(--ff)', fontSize: 17, fontWeight: 800, marginBottom: 8 }}>{p.title}</div>
            <div style={{ fontSize: 12, color: 'var(--muted)', lineHeight: 1.6 }}>{p.desc}</div>
          </BentoCard>
        ))}
      </motion.div>
    </div>
  )
}

function BentoCard({ children, span, rowSpan, style = {}, accent }: {
  children: React.ReactNode; span: string; rowSpan?: string; style?: React.CSSProperties; accent?: boolean
}) {
  return (
    <motion.div
      whileHover={{ y: -3, boxShadow: '0 16px 44px rgba(0,0,0,.35)' }}
      style={{
        gridColumn: `span ${span}`, gridRow: rowSpan ? `span ${rowSpan}` : undefined,
        background: accent
          ? 'linear-gradient(135deg,color-mix(in srgb,var(--a) 10%,var(--card)),var(--card))'
          : 'var(--card)',
        border: `1px solid ${accent ? 'color-mix(in srgb,var(--a) 15%,transparent)' : 'var(--border)'}`,
        borderRadius: 22, overflow: 'hidden', cursor: 'pointer', transition: 'border-color .3s',
        ...style,
      }}>
      {children}
    </motion.div>
  )
}

function ProjectVisual() {
  return (
    <div style={{ width: '100%', height: 176, borderRadius: 14, marginTop: 22,
      background: 'var(--card2)', overflow: 'hidden', position: 'relative' }}>
      <div style={{ position: 'absolute', inset: 0,
        backgroundImage: `linear-gradient(color-mix(in srgb,var(--a) 14%,transparent) 1px,transparent 1px),
          linear-gradient(90deg,color-mix(in srgb,var(--a) 14%,transparent) 1px,transparent 1px)`,
        backgroundSize: '20px 20px' }} />
      <div style={{ position: 'relative', zIndex: 1, padding: 16, display: 'flex', flexDirection: 'column', gap: 8 }}>
        <div style={{ height: 5, borderRadius: 3, background: 'linear-gradient(90deg,var(--a),var(--b))', width: '65%' }} />
        {[['ac','',''], ['','ac','ac'], ['ac','','ac']].map((row, ri) => (
          <div key={ri} style={{ display: 'flex', gap: 6 }}>
            {row.map((type, ci) => (
              <div key={ci} style={{ height: 24, borderRadius: 5, flex: 1,
                background: type === 'ac' ? 'color-mix(in srgb,var(--a) 25%,transparent)' : 'rgba(255,255,255,.07)' }} />
            ))}
          </div>
        ))}
      </div>
    </div>
  )
}

function Pill({ children, variant }: { children: React.ReactNode; variant: 'a' | 'b' | 'c' }) {
  const styles = {
    a: { background: 'color-mix(in srgb,var(--a) 12%,transparent)', border: '1px solid color-mix(in srgb,var(--a) 20%,transparent)', color: 'var(--a2)' },
    b: { background: 'color-mix(in srgb,var(--b) 10%,transparent)', border: '1px solid color-mix(in srgb,var(--b) 15%,transparent)', color: 'var(--b2)' },
    c: { background: 'rgba(255,255,255,.05)', border: '1px solid var(--border)', color: 'var(--muted)' },
  }
  return (
    <span style={{ display: 'inline-block', padding: '4px 12px', borderRadius: 100,
      fontSize: 11, fontWeight: 500, ...styles[variant] }}>
      {children}
    </span>
  )
}

// ═══════════════════════════════════════════════════════════════
// 4. SERVICES
// ═══════════════════════════════════════════════════════════════
export function Services() {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, amount: 0.1 })

  return (
    <div id="services" style={{ background: 'var(--deep)', padding: '80px 0' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 52px' }}>
        <SectionHeader tag="What I Do" title="Services built for modern teams" />
        <motion.div ref={ref}
          variants={staggerContainer(0.07)}
          initial="hidden" animate={inView ? 'show' : 'hidden'}
          style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 18 }}>
          {SERVICES.map(s => (
            <motion.div key={s.num} variants={staggerFade}
              whileHover={{ y: -5, boxShadow: '0 22px 52px rgba(0,0,0,.35)' }}
              style={{ background: 'var(--card)', border: '1px solid var(--border)',
                borderRadius: 22, padding: 36, cursor: 'pointer',
                position: 'relative', overflow: 'hidden', transition: 'border-color .3s' }}>
              {/* Bottom gradient line on hover — handled via CSS pseudoelement in production */}
              <span style={{ fontFamily: 'var(--fm)', fontSize: 10, color: 'var(--a2)',
                letterSpacing: '2px', marginBottom: 20, display: 'block' }}>{s.num}</span>
              <div style={{ fontFamily: 'var(--ff)', fontSize: 19, fontWeight: 700,
                letterSpacing: '-.4px', marginBottom: 11 }}>{s.title}</div>
              <div style={{ fontSize: 13, color: 'var(--muted)', lineHeight: 1.7 }}>{s.description}</div>
              <div style={{ marginTop: 26, fontSize: 12, color: 'var(--a2)', fontWeight: 500,
                display: 'flex', alignItems: 'center', gap: 6 }}>Explore <span>→</span></div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
// 5. ABOUT + SKILLS
// ═══════════════════════════════════════════════════════════════
const SKILLS = [
  { icon: '⚡', name: 'React / Next.js', pct: 96 },
  { icon: '🎭', name: 'UI/UX Design',    pct: 92 },
  { icon: '🎬', name: 'Motion & Animation', pct: 88 },
  { icon: '🔧', name: 'Backend / APIs',  pct: 80 },
  { icon: '🌐', name: '3D / WebGL',      pct: 75 },
  { icon: '📱', name: 'React Native',    pct: 70 },
]

export function About() {
  const leftRef = useRef(null)
  const rightRef = useRef(null)
  const leftInView = useInView(leftRef, { once: true, amount: 0.2 })
  const rightInView = useInView(rightRef, { once: true, amount: 0.2 })

  return (
    <div id="about" style={{ padding: '96px 52px', maxWidth: 1380, margin: '0 auto',
      display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 80, alignItems: 'start' }}>

      {/* Left: Copy */}
      <motion.div ref={leftRef} variants={fadeLeft} initial="hidden"
        animate={leftInView ? 'show' : 'hidden'}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontSize: 10,
          letterSpacing: '2.5px', textTransform: 'uppercase', color: 'var(--a2)', marginBottom: 18 }}>
          <span style={{ width: 18, height: 1, background: 'var(--a2)', display: 'block' }} />
          About Me
        </div>
        <h2 style={{ fontFamily: 'var(--ff)', fontSize: 'clamp(26px,4vw,46px)', fontWeight: 800,
          letterSpacing: '-1.5px', lineHeight: 1.05, marginBottom: 20 }}>
          I build interfaces<br />that feel like the future
        </h2>
        <p style={{ fontSize: 15, color: 'var(--muted)', lineHeight: 1.8, marginBottom: 18, fontWeight: 300 }}>
          Eight years crafting digital products for startups and Fortune 500 companies. My work sits
          at the intersection of engineering precision and design intuition — I believe great software
          should be as beautiful as it is functional.
        </p>
        <p style={{ fontSize: 15, color: 'var(--muted)', lineHeight: 1.8, marginBottom: 28, fontWeight: 300 }}>
          Currently available for select freelance projects. I work remotely from Berlin, collaborating
          with teams across North America, Europe, and Asia.
        </p>
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
          {['🇩🇪 Berlin-based', '🌍 Remote friendly'].map(t => (
            <span key={t} style={{ background: 'var(--card)', border: '1px solid var(--border)',
              borderRadius: 100, padding: '7px 16px', fontSize: 12, color: 'var(--muted)' }}>{t}</span>
          ))}
          <span style={{ background: 'color-mix(in srgb,var(--b) 10%,var(--card))',
            border: '1px solid color-mix(in srgb,var(--b) 20%,transparent)',
            borderRadius: 100, padding: '7px 16px', fontSize: 12, color: 'var(--b2)' }}>
            ● Open to work
          </span>
        </div>
      </motion.div>

      {/* Right: Skills */}
      <motion.div ref={rightRef} variants={fadeRight} initial="hidden"
        animate={rightInView ? 'show' : 'hidden'}
        style={{ display: 'grid', gridTemplateColumns: 'repeat(2,1fr)', gap: 12 }}>
        {SKILLS.map((sk, i) => (
          <SkillCard key={i} skill={sk} inView={rightInView} />
        ))}
      </motion.div>
    </div>
  )
}

function SkillCard({ skill, inView }: { skill: typeof SKILLS[0]; inView: boolean }) {
  return (
    <motion.div whileHover={{ y: -2, borderColor: 'var(--border2)' }}
      style={{ background: 'var(--card)', border: '1px solid var(--border)',
        borderRadius: 14, padding: 22, transition: 'all .3s' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
        <div style={{ width: 34, height: 34, borderRadius: 10, display: 'flex',
          alignItems: 'center', justifyContent: 'center', fontSize: 15,
          background: 'color-mix(in srgb,var(--a) 12%,transparent)' }}>{skill.icon}</div>
        <div style={{ fontFamily: 'var(--ff)', fontSize: 13, fontWeight: 700 }}>{skill.name}</div>
      </div>
      <div style={{ height: 3, borderRadius: 2, background: 'rgba(255,255,255,.07)', overflow: 'hidden' }}>
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: inView ? `${skill.pct}%` : 0 }}
          transition={{ duration: 1.4, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
          style={{ height: '100%', borderRadius: 2,
            background: 'linear-gradient(90deg,var(--a),var(--b))' }}
        />
      </div>
      <div style={{ fontFamily: 'var(--fm)', fontSize: 10, color: 'var(--muted2)',
        textAlign: 'right', marginTop: 5 }}>{skill.pct}%</div>
    </motion.div>
  )
}

// ═══════════════════════════════════════════════════════════════
// 6. TIMELINE
// ═══════════════════════════════════════════════════════════════
const TIMELINE_DATA = [
  { year: '2023 — Present', role: 'Senior Frontend Engineer & Design Lead', company: 'Vercel — San Francisco (Remote)', desc: 'Leading design and implementation of next-generation developer tooling. Reduced bundle size 40%, improved Core Web Vitals across 12 products.', active: true },
  { year: '2021 — 2023', role: 'UI Engineering Lead', company: 'Linear — Remote', desc: 'Built the component system powering Linear\'s product. Drove the design system from 0 to 180 components.' },
  { year: '2019 — 2021', role: 'Product Designer & Frontend Developer', company: 'Stripe — Dublin', desc: 'Designed and shipped key Stripe Dashboard features. Improved checkout conversion 18% through design research.' },
  { year: '2017 — 2019', role: 'Freelance Creative Developer', company: 'Independent — Berlin', desc: '40+ projects for startups and agencies across Europe and North America. Award-winning marketing websites.' },
]

export function Timeline() {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, amount: 0.1 })

  return (
    <div style={{ background: 'var(--deep)', padding: '80px 0' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 52px' }}>
        <SectionHeader tag="Experience" title="Career timeline" />
        <motion.div ref={ref}
          variants={staggerContainer(0.1)}
          initial="hidden" animate={inView ? 'show' : 'hidden'}
          style={{ position: 'relative', paddingLeft: 60 }}>
          {/* Line */}
          <div style={{ position: 'absolute', left: 20, top: 0, bottom: 0, width: 1,
            background: 'linear-gradient(to bottom,var(--a),transparent)' }} />
          {TIMELINE_DATA.map((item, i) => (
            <motion.div key={i} variants={staggerFade}
              style={{ marginBottom: i < TIMELINE_DATA.length - 1 ? 40 : 0, position: 'relative' }}>
              {/* Dot */}
              <div style={{
                position: 'absolute', left: -52, top: 0,
                width: 42, height: 42, borderRadius: '50%',
                background: item.active ? 'linear-gradient(135deg,var(--a),var(--c))' : 'var(--card)',
                border: item.active ? 'none' : '1px solid var(--border)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 13, boxShadow: item.active ? '0 0 20px color-mix(in srgb,var(--a) 40%,transparent)' : 'none',
              }}>
                {item.active ? '✦' : '◈'}
              </div>
              <div style={{ fontFamily: 'var(--fm)', fontSize: 11, color: 'var(--a2)',
                letterSpacing: '1px', marginBottom: 5 }}>{item.year}</div>
              <div style={{ fontFamily: 'var(--ff)', fontSize: 17, fontWeight: 700,
                letterSpacing: '-.3px', marginBottom: 3 }}>{item.role}</div>
              <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 9 }}>{item.company}</div>
              <div style={{ fontSize: 13, color: 'var(--muted)', lineHeight: 1.7, maxWidth: 480 }}>{item.desc}</div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
// 7. TESTIMONIALS
// ═══════════════════════════════════════════════════════════════
export function Testimonials() {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, amount: 0.1 })

  return (
    <div style={{ padding: '96px 52px', maxWidth: 1380, margin: '0 auto' }}>
      <SectionHeader tag="Testimonials" title="What clients say" />
      <motion.div ref={ref}
        variants={staggerContainer(0.1)}
        initial="hidden" animate={inView ? 'show' : 'hidden'}
        style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

        {/* Featured */}
        <motion.div variants={blurIn}
          style={{ background: 'linear-gradient(135deg,color-mix(in srgb,var(--a) 7%,var(--card)),var(--card))',
            border: '1px solid color-mix(in srgb,var(--a) 20%,transparent)',
            borderRadius: 22, padding: 40, position: 'relative', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', top: 24, right: 32, fontSize: 80, lineHeight: 1,
            color: 'color-mix(in srgb,var(--a) 10%,transparent)', fontFamily: 'Georgia,serif' }}>"</div>
          <Stars /><br />
          <div style={{ fontSize: 16, lineHeight: 1.75, marginBottom: 24, fontWeight: 300, maxWidth: 680 }}>
            Working with this developer completely transformed how we think about digital products.
            The attention to animation detail was extraordinary — PageSpeed went from 62 to 98
            and conversion jumped 34% in the first month.
          </div>
          <TestimonialAuthor initials="SL" name="Sarah Lindström" role="CPO at Axiom Labs · Stockholm" />
        </motion.div>

        {/* 2×2 Grid */}
        {[
          [
            { text: 'Delivered a Framer Motion design system in 3 weeks that would have taken our team 3 months. Clean code, great communication.', initials: 'MR', name: 'Marcus Rodriguez', role: 'CTO at Pulse · New York', color: 'linear-gradient(135deg,var(--b),var(--c))' },
            { text: 'The Awwwards SOTD we won is directly attributable to the frontend quality. Every interaction felt intentional and premium.', initials: 'JK', name: 'Julia Kim', role: 'Design Director at Nebula · Berlin', color: 'linear-gradient(135deg,#f43f5e,#f97316)' },
          ],
          [
            { text: 'The checkout redesign alone generated $400k additional revenue in Q1. Exceptional understanding of UX and business goals.', initials: 'TP', name: 'Thomas Park', role: 'CEO at Flux Commerce · Seoul', color: 'linear-gradient(135deg,#10b981,#3b82f6)' },
            { text: 'The most technically skilled and design-aware developer I\'ve ever worked with. Hired three times for our most critical launches.', initials: 'AM', name: 'Ana Martínez', role: 'VP Product at Helix · Barcelona', color: 'linear-gradient(135deg,#a855f7,#ec4899)' },
          ],
        ].map((row, ri) => (
          <div key={ri} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            {row.map((t, ti) => (
              <motion.div key={ti} variants={staggerFade}
                style={{ background: 'var(--card)', border: '1px solid var(--border)',
                  borderRadius: 22, padding: 36 }}>
                <Stars />
                <div style={{ fontSize: 14, lineHeight: 1.75, marginBottom: 22, fontWeight: 300 }}>{t.text}</div>
                <TestimonialAuthor initials={t.initials} name={t.name} role={t.role} avatarStyle={{ background: t.color }} />
              </motion.div>
            ))}
          </div>
        ))}
      </motion.div>
    </div>
  )
}

function Stars() {
  return (
    <div style={{ display: 'flex', gap: 2, marginBottom: 14 }}>
      {Array.from({ length: 5 }).map((_, i) => (
        <span key={i} style={{ color: '#f59e0b', fontSize: 13 }}>★</span>
      ))}
    </div>
  )
}

function TestimonialAuthor({ initials, name, role, avatarStyle = {} }: {
  initials: string; name: string; role: string; avatarStyle?: React.CSSProperties
}) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
      <div style={{ width: 42, height: 42, borderRadius: '50%',
        background: 'linear-gradient(135deg,var(--a),var(--c))',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontWeight: 700, fontSize: 13, flexShrink: 0, ...avatarStyle }}>
        {initials}
      </div>
      <div>
        <div style={{ fontWeight: 600, fontSize: 13 }}>{name}</div>
        <div style={{ fontSize: 12, color: 'var(--muted)' }}>{role}</div>
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
// 8. AWARDS
// ═══════════════════════════════════════════════════════════════
const AWARDS = [
  { icon: '🏆', name: 'Awwwards SOTD', sub: 'Site of the Day · 3× winner' },
  { icon: '⚡', name: 'FWA Award', sub: 'Favourite Website Award · 2024' },
  { icon: '🌐', name: 'Webby Nominee', sub: 'Best Visual Design · 2024' },
  { icon: '✦', name: 'CSS Design Awards', sub: 'Special Kudos · 2023' },
  { icon: '🎯', name: 'ThemeForest Elite', sub: 'Top 5% authors · 2023–2025' },
  { icon: '🚀', name: 'Product Hunt', sub: '#1 Product of the Day · 2×' },
  { icon: '💎', name: 'Dribbble Top Shot', sub: '200k+ views on single shot' },
  { icon: '📐', name: 'GitHub Stars', sub: '12,400+ across open source' },
]

export function Awards() {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, amount: 0.1 })

  return (
    <div style={{ background: 'var(--deep)', padding: '80px 0' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 52px' }}>
        <SectionHeader tag="Recognition" title="Awards & achievements" />
        <motion.div ref={ref}
          variants={staggerContainer(0.06)}
          initial="hidden" animate={inView ? 'show' : 'hidden'}
          style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 14 }}>
          {AWARDS.map((a, i) => (
            <motion.div key={i} variants={staggerFade}
              whileHover={{ y: -4, boxShadow: '0 16px 40px rgba(0,0,0,.3)', borderColor: 'var(--border2)' }}
              style={{ background: 'var(--card)', border: '1px solid var(--border)',
                borderRadius: 18, padding: 26, textAlign: 'center', transition: 'all .3s' }}>
              <span style={{ fontSize: 32, marginBottom: 12, display: 'block' }}>{a.icon}</span>
              <div style={{ fontFamily: 'var(--ff)', fontSize: 14, fontWeight: 700, marginBottom: 5 }}>{a.name}</div>
              <div style={{ fontSize: 11, color: 'var(--muted)' }}>{a.sub}</div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
// 9. PRICING
// ═══════════════════════════════════════════════════════════════
export function Pricing() {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, amount: 0.1 })

  return (
    <div id="pricing" style={{ padding: '96px 52px', maxWidth: 1380, margin: '0 auto' }}>
      <SectionHeader tag="Pricing" title="Transparent pricing"
        subtitle="Fixed-scope packages with clear deliverables. No hidden costs, no scope creep." />
      <motion.div ref={ref}
        variants={staggerContainer(0.1)}
        initial="hidden" animate={inView ? 'show' : 'hidden'}
        style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 18 }}>
        {PRICING.map((plan, i) => (
          <motion.div key={i} variants={staggerFade}
            whileHover={{ y: -4, boxShadow: '0 20px 48px rgba(0,0,0,.3)' }}
            style={{
              background: plan.featured
                ? 'linear-gradient(160deg,color-mix(in srgb,var(--a) 8%,var(--card)),var(--card))'
                : 'var(--card)',
              border: `1px solid ${plan.featured ? 'var(--a)' : 'var(--border)'}`,
              borderRadius: 22, padding: 36, position: 'relative', overflow: 'hidden', transition: 'all .3s',
            }}>
            {plan.featured && (
              <div style={{ position: 'absolute', top: 18, right: 18, background: 'var(--a)',
                color: '#fff', fontSize: 10, fontWeight: 700, padding: '4px 12px',
                borderRadius: 100, letterSpacing: '.5px' }}>Most Popular</div>
            )}
            <div style={{ fontSize: 11, letterSpacing: '2px', textTransform: 'uppercase',
              color: 'var(--muted2)', marginBottom: 14 }}>{plan.name}</div>
            <div style={{ fontFamily: 'var(--ff)', fontSize: 46, fontWeight: 800,
              letterSpacing: '-2px', lineHeight: 1 }}>{plan.price}</div>
            <div style={{ fontSize: 12, color: 'var(--muted)', margin: '4px 0 26px' }}>{plan.period}</div>
            <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column',
              gap: 11, marginBottom: 32 }}>
              {plan.features.map((f, fi) => (
                <li key={fi} style={{ fontSize: 13, color: f.included ? 'var(--text)' : 'var(--muted)',
                  display: 'flex', alignItems: 'center', gap: 10 }}>
                  <span style={{ fontSize: 11, width: 16, flexShrink: 0,
                    color: f.included ? 'var(--b)' : 'var(--muted2)' }}>
                    {f.included ? '✓' : '–'}
                  </span>
                  {f.label}
                </li>
              ))}
            </ul>
            <motion.button
              whileHover={{ filter: 'brightness(1.12)', y: -1 }}
              style={{
                width: '100%', padding: 13, borderRadius: 100, fontSize: 13,
                fontWeight: 600, cursor: 'pointer', transition: 'all .3s',
                border: plan.featured ? 'none' : '1px solid var(--border2)',
                background: plan.featured
                  ? 'linear-gradient(135deg,var(--a),var(--c))'
                  : 'transparent',
                color: plan.featured ? '#fff' : 'var(--text)',
                boxShadow: plan.featured ? '0 6px 20px color-mix(in srgb,var(--a) 30%,transparent)' : 'none',
              }}>
              {plan.cta}
            </motion.button>
          </motion.div>
        ))}
      </motion.div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
// 10. FAQ
// ═══════════════════════════════════════════════════════════════
const FAQ_DATA = [
  { q: 'What technologies do you work with?', a: 'I specialize in React, Next.js, TypeScript, Tailwind CSS, Framer Motion, and GSAP. Backends with Node.js, PostgreSQL, and Prisma. Design in Figma.' },
  { q: 'What is your typical project timeline?', a: 'A landing page takes 1–2 weeks. A full website 3–5 weeks. Larger applications are scoped individually. I always provide a detailed timeline before starting.' },
  { q: 'Do you work from existing designs or create from scratch?', a: 'Both! I can work from Figma files, or handle full design and development end-to-end. Many clients prefer the full-service approach since design and dev are deeply integrated in my workflow.' },
  { q: 'How do revisions work?', a: 'All packages include 2+ revision rounds. I use Loom videos and annotated screenshots for structured feedback. Additional rounds can be added at a fixed hourly rate.' },
  { q: 'Do you offer ongoing maintenance?', a: 'Yes. Monthly maintenance retainers from $400/month include 4 hours of work, priority support, dependency updates, and performance monitoring.' },
  { q: 'What makes NEXORA different from other templates?', a: 'NEXORA ships with 8 distinct homepage demos, premium cinematic animations, a complete design token system, 20+ reusable sections, and production-ready Next.js code. Every detail targets Awwwards quality.' },
  { q: 'Is the template easy to customize?', a: 'All colors, fonts, and spacing are driven by CSS custom properties and a centralized TypeScript config. Switch between all 8 demos by changing a single variable. Full documentation included.' },
]

export function FAQ() {
  const [open, setOpen] = useState<number | null>(null)
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, amount: 0.1 })

  return (
    <div style={{ background: 'var(--deep)', padding: '80px 0' }}>
      <div style={{ maxWidth: 780, margin: '0 auto', padding: '0 52px' }}>
        <SectionHeader tag="FAQ" title="Common questions" />
        <motion.div ref={ref}
          variants={staggerContainer(0.05)}
          initial="hidden" animate={inView ? 'show' : 'hidden'}
          style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {FAQ_DATA.map((item, i) => (
            <motion.div key={i} variants={staggerFade}
              style={{ background: 'var(--card)',
                border: `1px solid ${open === i ? 'var(--border2)' : 'var(--border)'}`,
                borderRadius: 14, overflow: 'hidden', transition: 'border-color .2s' }}>
              <button
                onClick={() => setOpen(open === i ? null : i)}
                style={{ width: '100%', padding: '20px 24px', display: 'flex',
                  alignItems: 'center', justifyContent: 'space-between', cursor: 'pointer',
                  fontSize: 14, fontWeight: 500, background: 'transparent', border: 'none',
                  color: open === i ? 'var(--a2)' : 'var(--text)', gap: 14, textAlign: 'left',
                  fontFamily: 'var(--fb)', transition: 'color .2s' }}>
                {item.q}
                <motion.div
                  animate={{ rotate: open === i ? 180 : 0 }}
                  transition={{ duration: 0.3 }}
                  style={{ width: 22, height: 22, borderRadius: '50%',
                    border: '1px solid var(--border2)', display: 'flex',
                    alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                    fontSize: 11, background: open === i ? 'var(--a)' : 'transparent',
                    borderColor: open === i ? 'var(--a)' : 'var(--border2)',
                    transition: 'background .3s, border-color .3s' }}>↓</motion.div>
              </button>
              <AnimatePresence>
                {open === i && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}>
                    <div style={{ padding: '0 24px 20px', fontSize: 13,
                      color: 'var(--muted)', lineHeight: 1.7 }}>{item.a}</div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
// 11. CONTACT
// ═══════════════════════════════════════════════════════════════
// ─── shared input style (removes outline:none — WCAG 2.4.7) ─────
const inputStyle: React.CSSProperties = {
  background: 'var(--surface)', border: '1px solid var(--border)',
  borderRadius: 10, padding: '12px 15px', fontSize: 13,
  color: 'var(--text)', fontFamily: 'var(--fb)', width: '100%',
  /* outline intentionally NOT set to none — :focus-visible ring from globals.css applies */
}

export function Contact() {
  const [status, setStatus] = useState<'idle' | 'sending' | 'sent' | 'error'>('idle')
  const [formData, setFormData] = useState({
    firstName: '', lastName: '', email: '', projectType: 'Website Design & Development', message: '',
  })
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, amount: 0.1 })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const handleSubmit = async () => {
    if (!formData.firstName || !formData.email || !formData.message) return
    setStatus('sending')
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          firstName: formData.firstName,
          lastName: formData.lastName,
          email: formData.email,
          projectType: formData.projectType,
          budget: '',
          message: formData.message,
        }),
      })
      if (!res.ok) throw new Error('Server error')
      setStatus('sent')
      setFormData({ firstName: '', lastName: '', email: '', projectType: 'Website Design & Development', message: '' })
      setTimeout(() => setStatus('idle'), 4000)
    } catch {
      setStatus('error')
      setTimeout(() => setStatus('idle'), 4000)
    }
  }

  return (
    <div id="contact" style={{ padding: '96px 52px', maxWidth: 1380, margin: '0 auto' }}>
      <SectionHeader tag="Contact" title={<>Let's build something<br />remarkable together</>} />
      <motion.div ref={ref}
        style={{ display: 'grid', gridTemplateColumns: '1fr 1.2fr', gap: 52, alignItems: 'start' }}>

        {/* Info */}
        <motion.div variants={fadeLeft} initial="hidden" animate={inView ? 'show' : 'hidden'}>
          {[
            { ico: '✉', label: 'Email', value: 'hello@your-domain.com' },
            { ico: '💼', label: 'LinkedIn', value: 'linkedin.com/in/your-profile' },
            { ico: '⏱', label: 'Timezone', value: 'Your Timezone Here' },
            { ico: '⚡', label: 'Response Time', value: 'Within 24 hours' },
          ].map((ci, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 14, marginBottom: 24 }}>
              <div style={{ width: 40, height: 40, borderRadius: 11, flexShrink: 0,
                background: 'color-mix(in srgb,var(--a) 12%,transparent)',
                border: '1px solid color-mix(in srgb,var(--a) 20%,transparent)',
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 15 }}
                aria-hidden="true">{ci.ico}</div>
              <div>
                <div style={{ fontSize: 10, color: 'var(--muted2)', letterSpacing: '1px',
                  textTransform: 'uppercase', marginBottom: 3 }}>{ci.label}</div>
                <div style={{ fontSize: 14, fontWeight: 500 }}>{ci.value}</div>
              </div>
            </div>
          ))}
          <div style={{ padding: 22,
            background: 'linear-gradient(135deg,color-mix(in srgb,var(--a) 8%,transparent),color-mix(in srgb,var(--b) 5%,transparent))',
            border: '1px solid color-mix(in srgb,var(--a) 15%,transparent)', borderRadius: 16, marginTop: 8 }}>
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: 10 }}>
              <span style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--b)',
                boxShadow: '0 0 10px var(--b)', display: 'inline-block', marginRight: 8 }}
                aria-hidden="true" />
              <span style={{ fontSize: 13, fontWeight: 500, color: 'var(--b2)' }}>
                Currently available for new projects
              </span>
            </div>
            <div style={{ fontSize: 13, color: 'var(--muted)', lineHeight: 1.6 }}>
              Reach out early — spots fill up quickly.
            </div>
          </div>
        </motion.div>

        {/* Form */}
        <motion.div variants={fadeRight} initial="hidden" animate={inView ? 'show' : 'hidden'}
          style={{ background: 'var(--card)', border: '1px solid var(--border)',
            borderRadius: 22, padding: 34, display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            {([['First Name', 'firstName', 'Alex'], ['Last Name', 'lastName', 'Chen']] as const).map(([label, name, ph]) => (
              <div key={name} style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                <label htmlFor={`cf-${name}`} style={{ fontSize: 10, color: 'var(--muted2)', letterSpacing: '1px', textTransform: 'uppercase' }}>{label}</label>
                <input
                  id={`cf-${name}`}
                  name={name}
                  value={formData[name as 'firstName' | 'lastName']}
                  onChange={handleChange}
                  placeholder={ph}
                  style={inputStyle}
                  required={name === 'firstName'}
                />
              </div>
            ))}
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <label htmlFor="cf-email" style={{ fontSize: 10, color: 'var(--muted2)', letterSpacing: '1px', textTransform: 'uppercase' }}>Email</label>
            <input
              id="cf-email"
              name="email"
              type="email"
              required
              value={formData.email}
              onChange={handleChange}
              placeholder="alex@company.com"
              style={inputStyle}
            />
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <label htmlFor="cf-projectType" style={{ fontSize: 10, color: 'var(--muted2)', letterSpacing: '1px', textTransform: 'uppercase' }}>Project Type</label>
            <select
              id="cf-projectType"
              name="projectType"
              value={formData.projectType}
              onChange={handleChange}
              style={{ ...inputStyle, cursor: 'pointer' }}>
              {['Website Design & Development','UI/UX Design','Design System','Motion & Animation','Full-Stack Application','Consulting'].map(o => <option key={o}>{o}</option>)}
            </select>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <label htmlFor="cf-message" style={{ fontSize: 10, color: 'var(--muted2)', letterSpacing: '1px', textTransform: 'uppercase' }}>About your project</label>
            <textarea
              id="cf-message"
              name="message"
              rows={4}
              required
              value={formData.message}
              onChange={handleChange}
              placeholder="We're building a SaaS platform and need help with..."
              style={{ ...inputStyle, resize: 'none' }}
            />
          </div>
          {/* Status message (announced to screen readers via aria-live) */}
          {status === 'error' && (
            <div role="alert" style={{ fontSize: 13, color: '#f87171', padding: '10px 14px',
              background: 'rgba(248,113,113,0.08)', borderRadius: 8, border: '1px solid rgba(248,113,113,0.2)' }}>
              Something went wrong. Please try again or email us directly.
            </div>
          )}
          <div aria-live="polite" aria-atomic="true" className="sr-only">
            {status === 'sent' ? 'Your message was sent successfully.' : ''}
          </div>
          <motion.button
            type="button"
            whileHover={{ filter: 'brightness(1.1)', y: -1 }}
            whileTap={{ scale: 0.99 }}
            onClick={handleSubmit}
            disabled={status === 'sending'}
            aria-disabled={status === 'sending'}
            style={{ background: status === 'sent' ? 'linear-gradient(135deg,#059669,#10b981)' : 'linear-gradient(135deg,var(--a),var(--c))',
              color: '#fff', padding: '14px', borderRadius: 12, fontSize: 14, fontWeight: 600,
              border: 'none', cursor: status === 'sending' ? 'wait' : 'pointer', width: '100%',
              boxShadow: '0 4px 20px color-mix(in srgb,var(--a) 30%,transparent)',
              transition: 'background .4s', opacity: status === 'sending' ? 0.75 : 1 }}>
            {status === 'idle' ? 'Send Message →' : status === 'sending' ? 'Sending…' : status === 'sent' ? 'Message Sent ✓' : 'Try Again →'}
          </motion.button>
        </motion.div>
      </motion.div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
// 12. NEWSLETTER
// ═══════════════════════════════════════════════════════════════
export function Newsletter() {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, amount: 0.3 })

  return (
    <div style={{ padding: '0 52px 80px', maxWidth: 1280, margin: '0 auto' }}>
      <motion.div ref={ref} variants={scaleIn} initial="hidden"
        animate={inView ? 'show' : 'hidden'}
        style={{ background: 'linear-gradient(135deg,color-mix(in srgb,var(--a) 10%,var(--card)),color-mix(in srgb,var(--b) 6%,var(--card)))',
          border: '1px solid color-mix(in srgb,var(--a) 15%,transparent)',
          borderRadius: 26, padding: 52, textAlign: 'center', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 100%,color-mix(in srgb,var(--a) 12%,transparent),transparent 60%)', pointerEvents: 'none' }} />
        <div style={{ fontFamily: 'var(--ff)', fontSize: 34, fontWeight: 800, letterSpacing: '-1.5px', marginBottom: 10, position: 'relative' }}>Stay in the loop</div>
        <div style={{ fontSize: 14, color: 'var(--muted)', marginBottom: 28, position: 'relative' }}>Monthly insights on design, animation, and frontend engineering. No spam, ever.</div>
        <div style={{ display: 'flex', gap: 10, justifyContent: 'center', maxWidth: 440, margin: '0 auto', position: 'relative' }}>
          <input type="email" placeholder="your@email.com" style={{ flex: 1, background: 'var(--surface)', border: '1px solid var(--border2)', borderRadius: 100, padding: '13px 20px', fontSize: 13, color: 'var(--text)', fontFamily: 'var(--fb)', outline: 'none' }} />
          <motion.button whileHover={{ filter: 'brightness(1.1)' }}
            style={{ background: 'linear-gradient(135deg,var(--a),var(--c))', color: '#fff', padding: '13px 22px', borderRadius: 100, fontSize: 13, fontWeight: 600, border: 'none', cursor: 'pointer', whiteSpace: 'nowrap' }}>
            Subscribe →
          </motion.button>
        </div>
      </motion.div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
// EXPORT ALL
// ═══════════════════════════════════════════════════════════════
export default {
  Ticker, StatsBar, BentoGrid, Services, About, Timeline,
  Testimonials, Awards, Pricing, FAQ, Contact, Newsletter,
}
