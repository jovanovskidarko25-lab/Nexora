// sections/heroes/index.tsx
// NEXORA — All 8 Hero Section Components
// Each hero has unique copy, layout, extras, and is theme-aware via CSS vars

'use client'

import React, { useEffect, useRef } from 'react'
import { motion } from 'framer-motion'
import { heroContainer, heroBadge, heroTitle, heroSub, blurIn } from '@/lib/animations'

// ─── SHARED PARTS ───────────────────────────────────────────────
function HeroBg() {
  return (
    <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', width: 700, height: 700, borderRadius: '50%',
        background: 'radial-gradient(circle,var(--ga) 0%,transparent 65%)',
        top: -200, right: -150, animation: 'oF 9s ease-in-out infinite' }} />
      <div style={{ position: 'absolute', width: 550, height: 550, borderRadius: '50%',
        background: 'radial-gradient(circle,var(--gb) 0%,transparent 65%)',
        bottom: -150, left: -100, animation: 'oF 11s ease-in-out infinite reverse' }} />
      <div style={{ position: 'absolute', inset: 0,
        backgroundImage: 'linear-gradient(rgba(255,255,255,.022) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.022) 1px,transparent 1px)',
        backgroundSize: '56px 56px',
        maskImage: 'radial-gradient(ellipse 80% 60% at 50% 50%,black,transparent)' }} />
      <div style={{ position: 'absolute', inset: 0, opacity: .04,
        backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='4'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")`,
        backgroundSize: '128px' }} />
      {/* Floating shapes */}
      {[
        { w:80, h:80, t:'22%', l:'7%', b:'var(--a)', anim:'oF 6s ease-in-out infinite' },
        { w:48, h:48, t:'66%', l:'88%', b:'var(--b)', anim:'oF 8s ease-in-out infinite reverse' },
      ].map((s,i) => (
        <div key={i} style={{ position:'absolute', width:s.w, height:s.h, borderRadius:'50%',
          border:`1px solid ${s.b}`, top:s.t, left:s.l, opacity:.25, animation:s.anim }} />
      ))}
    </div>
  )
}

function Badge({ children }: { children: React.ReactNode }) {
  return (
    <motion.div variants={heroBadge}
      style={{ display: 'inline-flex', alignItems: 'center', gap: 8,
        background: 'color-mix(in srgb,var(--a) 12%,transparent)',
        border: '1px solid color-mix(in srgb,var(--a) 25%,transparent)',
        borderRadius: 100, padding: '6px 16px 6px 8px', marginBottom: 28,
        fontSize: 11, fontWeight: 500, letterSpacing: '.6px', color: 'var(--a2)' }}>
      <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--b)',
        boxShadow: '0 0 10px var(--b)', flexShrink: 0, animation: 'bp 2s ease-in-out infinite' }} />
      {children}
    </motion.div>
  )
}

function HeroBtns({ primary, secondary, onPrimary, onSecondary }: {
  primary: string; secondary: string; onPrimary?: () => void; onSecondary?: () => void
}) {
  return (
    <motion.div variants={heroSub}
      style={{ display: 'flex', gap: 14, justifyContent: 'center', flexWrap: 'wrap' }}>
      <motion.button whileHover={{ y: -2 }} onClick={onPrimary}
        style={{ background: 'linear-gradient(135deg,var(--a),var(--c))', color: '#fff',
          padding: '13px 30px', borderRadius: 100, fontSize: 14, fontWeight: 600,
          border: 'none', cursor: 'pointer',
          boxShadow: '0 4px 20px color-mix(in srgb,var(--a) 35%,transparent)' }}>
        {primary}
      </motion.button>
      <motion.button whileHover={{ background: 'var(--surface)' }} onClick={onSecondary}
        style={{ background: 'transparent', color: 'var(--text)', padding: '13px 30px',
          borderRadius: 100, fontSize: 14, fontWeight: 500,
          border: '1px solid var(--border2)', cursor: 'pointer' }}>
        {secondary}
      </motion.button>
    </motion.div>
  )
}

const heroWrap: React.CSSProperties = {
  minHeight: '100vh', display: 'flex', flexDirection: 'column',
  alignItems: 'center', justifyContent: 'center', position: 'relative',
  overflow: 'hidden', padding: '120px 52px 80px', textAlign: 'center',
}

// ═══════════════════════════════════════════════════════════════
// HERO 1 — AI Engineer (default purple/cyan)
// ═══════════════════════════════════════════════════════════════
export function HeroAI() {
  return (
    <div style={heroWrap}>
      <HeroBg />
      <motion.div variants={heroContainer} initial="hidden" animate="show"
        style={{ position: 'relative', zIndex: 2, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <Badge>⚡ Available for Freelance — 2026</Badge>
        <motion.h1 variants={heroTitle}
          style={{ fontFamily: 'var(--ff)', fontSize: 'clamp(46px,7vw,92px)', fontWeight: 800,
            lineHeight: 1.0, letterSpacing: '-3px', maxWidth: 960, margin: '0 auto 20px' }}>
          Design that moves.
          <span style={{ background: 'linear-gradient(135deg,var(--a2),var(--b2))',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', display: 'block' }}>
            Code that scales.
          </span>
        </motion.h1>
        <motion.p variants={heroSub}
          style={{ fontSize: 17, color: 'var(--muted)', maxWidth: 500, margin: '0 auto 44px',
            lineHeight: 1.75, fontWeight: 300 }}>
          Full-stack creative engineer crafting premium digital experiences at the intersection of design and technology.
        </motion.p>
        <HeroBtns primary="View My Work →" secondary="Get In Touch" />
      </motion.div>
      <ScrollIndicator />
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
// HERO 2 — Creative Developer (rose/orange)
// ═══════════════════════════════════════════════════════════════
export function HeroCreative() {
  return (
    <div style={heroWrap}>
      <HeroBg />
      <motion.div variants={heroContainer} initial="hidden" animate="show"
        style={{ position: 'relative', zIndex: 2, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <Badge>🎨 Creative Developer — Open to Work</Badge>
        <motion.h1 variants={heroTitle}
          style={{ fontFamily: 'var(--ff)', fontSize: 'clamp(46px,7vw,92px)', fontWeight: 800,
            lineHeight: 1.0, letterSpacing: '-3px', maxWidth: 960, margin: '0 auto 20px' }}>
          I craft interfaces
          <span style={{ background: 'linear-gradient(135deg,var(--a2),var(--b2))',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', display: 'block' }}>
            that feel alive.
          </span>
        </motion.h1>
        <motion.p variants={heroSub}
          style={{ fontSize: 17, color: 'var(--muted)', maxWidth: 500, margin: '0 auto 44px', lineHeight: 1.75, fontWeight: 300 }}>
          UI engineer and visual designer obsessed with micro-interactions, motion systems, and bold digital aesthetics that stop thumbs.
        </motion.p>
        <HeroBtns primary="See My Projects →" secondary="Say Hello" />
      </motion.div>
      <ScrollIndicator />
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
// HERO 3 — Cybersecurity (matrix green + terminal)
// ═══════════════════════════════════════════════════════════════
export function HeroCyber() {
  return (
    <div style={heroWrap}>
      <HeroBg />
      <motion.div variants={heroContainer} initial="hidden" animate="show"
        style={{ position: 'relative', zIndex: 2, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <Badge>🔐 Security Engineer · Remote · Open to Work</Badge>
        <motion.h1 variants={heroTitle}
          style={{ fontFamily: 'var(--ff)', fontSize: 'clamp(46px,7vw,92px)', fontWeight: 800,
            lineHeight: 1.0, letterSpacing: '-3px', maxWidth: 960, margin: '0 auto 20px' }}>
          <span style={{ background: 'linear-gradient(135deg,var(--a2),var(--b2))',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
            Breaking systems.
          </span>
          <br />Building resilience.
        </motion.h1>
        <motion.p variants={heroSub}
          style={{ fontSize: 17, color: 'var(--muted)', maxWidth: 500, margin: '0 auto 28px', lineHeight: 1.75, fontWeight: 300 }}>
          Cybersecurity specialist with 8+ years in penetration testing, red teaming, and secure software architecture.
        </motion.p>
        {/* Terminal block */}
        <motion.div variants={blurIn}
          style={{ background: 'rgba(0,255,136,.05)', border: '1px solid rgba(0,255,136,.15)',
            borderRadius: 12, padding: '20px 24px', fontFamily: 'var(--fm)', fontSize: 13,
            color: 'var(--a2)', margin: '0 auto 36px', textAlign: 'left', maxWidth: 500, width: '100%' }}>
          {['scanning target 192.168.x.x','port 443: OPEN [TLS 1.3]','vulnerabilities found: 0','status: SECURED'].map((line, i) => (
            <div key={i} style={{ marginBottom: 5, opacity: .88 }}>
              <span style={{ color: 'var(--a)' }}>&gt; </span>{line}
              {i === 3 && <span style={{ display: 'inline-block', width: 7, height: 13,
                background: 'var(--a)', animation: 'blink 1s step-end infinite', verticalAlign: 'middle', marginLeft: 2 }} />}
            </div>
          ))}
        </motion.div>
        <HeroBtns primary="View Case Studies →" secondary="Hire Me" />
      </motion.div>
      <ScrollIndicator />
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
// HERO 4 — Luxury Minimal (gold)
// ═══════════════════════════════════════════════════════════════
export function HeroLuxury() {
  return (
    <div style={heroWrap}>
      <HeroBg />
      <motion.div variants={heroContainer} initial="hidden" animate="show"
        style={{ position: 'relative', zIndex: 2, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <Badge>✦ Premium Creative Services · Est. 2017</Badge>
        <motion.span variants={heroBadge}
          style={{ fontFamily: 'var(--fs)', fontStyle: 'italic', fontSize: 22,
            color: 'var(--a2)', letterSpacing: '1px', marginBottom: 12, display: 'block' }}>
          "Where craft meets technology"
        </motion.span>
        <motion.h1 variants={heroTitle}
          style={{ fontFamily: 'var(--ff)', fontSize: 'clamp(46px,7vw,92px)', fontWeight: 700,
            lineHeight: 1.0, letterSpacing: '-2px', maxWidth: 960, margin: '0 auto 20px' }}>
          <span style={{ background: 'linear-gradient(135deg,var(--a2),var(--b2))',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Artistry.</span>
          <br />Precision. Vision.
        </motion.h1>
        <motion.p variants={heroSub}
          style={{ fontSize: 16, color: 'var(--muted)', maxWidth: 460, margin: '0 auto 44px', lineHeight: 1.75, fontWeight: 300 }}>
          High-end digital experiences for luxury brands, premium consultancies, and discerning clients who demand excellence without compromise.
        </motion.p>
        <HeroBtns primary="View Portfolio →" secondary="Enquire Now" />
      </motion.div>
      <ScrollIndicator />
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
// HERO 5 — Motion Designer (violet/fuchsia + reel pills)
// ═══════════════════════════════════════════════════════════════
export function HeroMotion() {
  const reelItems = ['Title Sequences','UI Animation','Brand Motion','3D Renders','VFX','Explainer Films']
  return (
    <div style={heroWrap}>
      <HeroBg />
      <motion.div variants={heroContainer} initial="hidden" animate="show"
        style={{ position: 'relative', zIndex: 2, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <Badge>🎬 Motion Designer & Art Director</Badge>
        <motion.h1 variants={heroTitle}
          style={{ fontFamily: 'var(--ff)', fontSize: 'clamp(46px,7vw,92px)', fontWeight: 800,
            lineHeight: 1.0, letterSpacing: '-3px', maxWidth: 960, margin: '0 auto 20px' }}>
          Motion is
          <span style={{ background: 'linear-gradient(135deg,var(--a2),var(--b2))',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', display: 'block' }}>
            the language of emotion.
          </span>
        </motion.h1>
        <motion.p variants={heroSub}
          style={{ fontSize: 17, color: 'var(--muted)', maxWidth: 500, margin: '0 auto 28px', lineHeight: 1.75, fontWeight: 300 }}>
          Award-winning motion designer crafting cinematic digital experiences for brands, films, and platforms worldwide.
        </motion.p>
        {/* Reel pills */}
        <motion.div variants={heroSub}
          style={{ display: 'flex', gap: 10, justifyContent: 'center', flexWrap: 'wrap', marginBottom: 28 }}>
          {reelItems.map(r => (
            <span key={r} style={{ padding: '8px 18px', borderRadius: 100, border: '1px solid var(--border2)',
              fontSize: 12, color: 'var(--muted)', transition: 'all .3s', cursor: 'default' }}>{r}</span>
          ))}
        </motion.div>
        <HeroBtns primary="Watch Showreel →" secondary="Book a Call" />
      </motion.div>
      <ScrollIndicator />
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
// HERO 6 — Agency (bold monochrome + stats)
// ═══════════════════════════════════════════════════════════════
export function HeroAgency() {
  const stats = [{ n: '200+', l: 'Brands built' },{ n: '94%', l: 'Retention' },{ n: '3×', l: 'Avg ROI' }]
  return (
    <div style={{ ...heroWrap, textAlign: 'left', alignItems: 'flex-start', padding: '120px 80px 80px' }}>
      <HeroBg />
      <motion.div variants={heroContainer} initial="hidden" animate="show"
        style={{ position: 'relative', zIndex: 2, maxWidth: 800 }}>
        <motion.div variants={heroBadge}
          style={{ display: 'inline-flex', alignItems: 'center', gap: 8,
            background: 'color-mix(in srgb,var(--a) 8%,transparent)',
            border: '1px solid color-mix(in srgb,var(--a) 15%,transparent)',
            borderRadius: 100, padding: '6px 16px 6px 8px', marginBottom: 28,
            fontSize: 11, fontWeight: 500, letterSpacing: '.6px', color: 'var(--a2)' }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--b)', flexShrink: 0 }} />
          🏢 Full-Service Digital Agency · Berlin
        </motion.div>
        <motion.h1 variants={heroTitle}
          style={{ fontFamily: 'var(--ff)', fontSize: 'clamp(52px,7vw,100px)', fontWeight: 800,
            lineHeight: .95, letterSpacing: '-4px', marginBottom: 28 }}>
          We make brands
          <span style={{ background: 'linear-gradient(135deg,var(--b2),var(--a2))',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', display: 'block' }}>
            unforgettable.
          </span>
        </motion.h1>
        <motion.p variants={heroSub}
          style={{ fontSize: 17, color: 'var(--muted)', maxWidth: 460, marginBottom: 40, lineHeight: 1.75, fontWeight: 300 }}>
          A boutique digital agency specialising in brand identity, web experience, and campaigns for ambitious companies.
        </motion.p>
        <motion.div variants={heroSub} style={{ display: 'flex', gap: 14, flexWrap: 'wrap', marginBottom: 52 }}>
          <motion.button whileHover={{ y: -2 }}
            style={{ background: 'linear-gradient(135deg,var(--a),var(--c))', color: '#000',
              padding: '13px 30px', borderRadius: 100, fontSize: 14, fontWeight: 700, border: 'none', cursor: 'pointer' }}>
            See Our Work →
          </motion.button>
          <motion.button whileHover={{ background: 'var(--surface)' }}
            style={{ background: 'transparent', color: 'var(--text)', padding: '13px 30px',
              borderRadius: 100, fontSize: 14, fontWeight: 500, border: '1px solid var(--border2)', cursor: 'pointer' }}>
            Start a Project
          </motion.button>
        </motion.div>
        {/* Stats */}
        <motion.div variants={heroSub}
          style={{ display: 'flex', gap: 40 }}>
          {stats.map(s => (
            <div key={s.l}>
              <div style={{ fontFamily: 'var(--ff)', fontSize: 32, fontWeight: 800,
                background: 'linear-gradient(135deg,var(--text),var(--muted))',
                WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>{s.n}</div>
              <div style={{ fontSize: 10, color: 'var(--muted2)', letterSpacing: '1.2px', textTransform: 'uppercase' }}>{s.l}</div>
            </div>
          ))}
        </motion.div>
      </motion.div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
// HERO 7 — Freelancer (amber/red + trust signals)
// ═══════════════════════════════════════════════════════════════
export function HeroFreelancer() {
  const trust = ['✓ Fixed-price packages', '✓ On-time delivery', '✓ 48h response', '✓ 5★ rated']
  return (
    <div style={heroWrap}>
      <HeroBg />
      <motion.div variants={heroContainer} initial="hidden" animate="show"
        style={{ position: 'relative', zIndex: 2, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <Badge>⚡ Available Now · Fast Delivery · Fixed Rates</Badge>
        <motion.h1 variants={heroTitle}
          style={{ fontFamily: 'var(--ff)', fontSize: 'clamp(46px,7vw,92px)', fontWeight: 800,
            lineHeight: 1.0, letterSpacing: '-3px', maxWidth: 960, margin: '0 auto 20px' }}>
          Your vision.
          <span style={{ background: 'linear-gradient(135deg,var(--a2),var(--b2))',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', display: 'block' }}>
            My expertise.
          </span>
        </motion.h1>
        <motion.p variants={heroSub}
          style={{ fontSize: 17, color: 'var(--muted)', maxWidth: 500, margin: '0 auto 28px', lineHeight: 1.75, fontWeight: 300 }}>
          Experienced freelance designer and developer specialising in high-converting websites, SaaS interfaces, and e-commerce.
        </motion.p>
        {/* Trust signals */}
        <motion.div variants={heroSub}
          style={{ display: 'flex', gap: 14, flexWrap: 'wrap', justifyContent: 'center', marginBottom: 36 }}>
          {trust.map(t => (
            <span key={t} style={{ background: 'color-mix(in srgb,var(--a) 10%,transparent)',
              border: '1px solid color-mix(in srgb,var(--a) 20%,transparent)',
              borderRadius: 100, padding: '6px 16px', fontSize: 12, color: 'var(--a2)', fontWeight: 500 }}>{t}</span>
          ))}
        </motion.div>
        <HeroBtns primary="Browse Packages →" secondary="Get Free Quote" />
      </motion.div>
      <ScrollIndicator />
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
// HERO 8 — Interactive 3D (deep space + particle canvas)
// ═══════════════════════════════════════════════════════════════
export function Hero3D() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let raf: number
    const resize = () => {
      canvas.width = canvas.offsetWidth
      canvas.height = canvas.offsetHeight
    }
    resize()
    window.addEventListener('resize', resize)

    const W = canvas.width, H = canvas.height
    const pts = Array.from({ length: 150 }, () => ({
      x: Math.random() * W, y: Math.random() * H, z: Math.random() * 900,
      vx: (Math.random() - .5) * .25, vy: (Math.random() - .5) * .25,
      vz: -.4 - Math.random() * .4, r: 1 + Math.random() * 2,
    }))

    const frame = () => {
      ctx.clearRect(0, 0, W, H)
      pts.forEach(p => {
        p.x += p.vx; p.y += p.vy; p.z += p.vz
        if (p.z < 1) p.z = 900
        if (p.x < 0) p.x = W; if (p.x > W) p.x = 0
        if (p.y < 0) p.y = H; if (p.y > H) p.y = 0
        const sc = 700 / p.z
        const sx = (p.x - W / 2) * sc + W / 2
        const sy = (p.y - H / 2) * sc + H / 2
        const al = Math.min(1, (1 - p.z / 900) * 1.5)
        ctx.beginPath(); ctx.arc(sx, sy, p.r * sc * .7, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(99,102,241,${al * .8})`; ctx.fill()

        pts.forEach(q => {
          const sc2 = 700 / q.z
          const sx2 = (q.x - W / 2) * sc2 + W / 2
          const sy2 = (q.y - H / 2) * sc2 + H / 2
          const d = Math.hypot(sx - sx2, sy - sy2)
          if (d < 90 && d > 0) {
            ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(sx2, sy2)
            ctx.strokeStyle = `rgba(6,182,212,${(1 - d / 90) * .14})`
            ctx.lineWidth = .5; ctx.stroke()
          }
        })
      })
      raf = requestAnimationFrame(frame)
    }
    frame()

    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener('resize', resize)
    }
  }, [])

  return (
    <div style={heroWrap}>
      {/* BG */}
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
        <canvas ref={canvasRef} style={{ width: '100%', height: '100%', opacity: .65, display: 'block' }} />
        <div style={{ position: 'absolute', inset: 0,
          backgroundImage: 'linear-gradient(rgba(99,102,241,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(99,102,241,.04) 1px,transparent 1px)',
          backgroundSize: '56px 56px' }} />
      </div>
      <motion.div variants={heroContainer} initial="hidden" animate="show"
        style={{ position: 'relative', zIndex: 2, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <Badge>🌐 3D Designer & WebGL Developer</Badge>
        <motion.h1 variants={heroTitle}
          style={{ fontFamily: 'var(--ff)', fontSize: 'clamp(46px,7vw,92px)', fontWeight: 800,
            lineHeight: 1.0, letterSpacing: '-3px', maxWidth: 960, margin: '0 auto 20px' }}>
          Enter the
          <span style={{ background: 'linear-gradient(135deg,var(--a2),var(--b2))',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', display: 'block' }}>
            third dimension.
          </span>
        </motion.h1>
        <motion.p variants={heroSub}
          style={{ fontSize: 17, color: 'var(--muted)', maxWidth: 500, margin: '0 auto 44px', lineHeight: 1.75, fontWeight: 300 }}>
          WebGL artist and Three.js developer creating immersive 3D web experiences, interactive installations, and real-time visualizations.
        </motion.p>
        <HeroBtns primary="Explore 3D Work →" secondary="Commission Work" />
      </motion.div>
      <ScrollIndicator />
    </div>
  )
}

// ─── SCROLL INDICATOR ───────────────────────────────────────────
function ScrollIndicator() {
  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: .8 }}
      style={{ position: 'absolute', bottom: 36, left: '50%', transform: 'translateX(-50%)',
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
      <div style={{ width: 1, height: 44, background: 'linear-gradient(to bottom,var(--a),transparent)',
        animation: 'sL 2s ease-in-out infinite' }} />
      <span style={{ fontSize: 10, letterSpacing: '3px', color: 'var(--muted2)', textTransform: 'uppercase' }}>Scroll</span>
    </motion.div>
  )
}

// ─── MAP demo id → component ────────────────────────────────────
export const HERO_MAP: Record<string, React.ComponentType> = {
  ai: HeroAI,
  creative: HeroCreative,
  cyber: HeroCyber,
  luxury: HeroLuxury,
  motion: HeroMotion,
  agency: HeroAgency,
  freelancer: HeroFreelancer,
  '3d': Hero3D,
}
