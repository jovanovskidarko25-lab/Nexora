# NEXORA — Ultra Premium Portfolio Template
### Version 2.0.1 | 

---

## 📋 Table of Contents
1. [Overview](#overview)
2. [Tech Stack](#tech-stack)
3. [Folder Structure](#folder-structure)
4. [Installation](#installation)
5. [Homepage Demos](#homepage-demos)
6. [Sections Reference](#sections-reference)
7. [Theme Customization](#theme-customization)
8. [Typography](#typography)
9. [Color System](#color-system)
10. [Animation Guide](#animation-guide)
11. [3D Effects](#3d-effects)
12. [SEO Setup](#seo-setup)
13. [Deployment](#deployment)
14. [FAQ](#faq)

---

## Overview

NEXORA is an ultra-premium portfolio template designed for:
- Full-stack developers
- UI/UX designers
- Motion designers
- Cybersecurity specialists
- Creative agencies
- Freelancers

It ships with **8 unique homepage demos**, **20+ reusable sections**, cinematic animations, and a design quality targeting Awwwards, FWA.

---

## Tech Stack

| Tool | Version | Purpose |
|------|---------|---------|
| Next.js | 15 (App Router) | Framework |
| React | 19 | UI library |
| TypeScript | 5.x | Type safety |
| Tailwind CSS | v4 | Styling |
| Framer Motion | 11.x | Animations |
| GSAP | 3.x | Advanced scroll animations |
| Lenis | 1.x | Smooth scrolling |
| React Three Fiber | 8.x | 3D graphics |
| Shadcn UI | latest | Component primitives |
| Lucide Icons | latest | Icon system |

---

## Folder Structure

> **Note:** All files are already structured correctly in the downloaded zip.
> Extract it, run `npm install`, and you're ready.

```
nexora/
├── app/
│   ├── layout.tsx          # Root layout, fonts, metadata
│   ├── page.tsx            # Homepage (demo switcher)
│   ├── work/
│   │   └── [slug]/page.tsx # Project detail pages
│   ├── blog/
│   │   ├── page.tsx        # Blog listing
│   │   └── [slug]/page.tsx # Blog post
│   ├── about/page.tsx
│   ├── services/page.tsx
│   ├── contact/page.tsx
│   └── globals.css
│
├── components/
│   ├── ui/                 # Shadcn primitives
│   ├── layout/
│   │   ├── Navbar.tsx
│   │   └── Footer.tsx
│   └── shared/
│       ├── CustomCursor.tsx
│       ├── PageTransition.tsx
│       ├── SmoothScroll.tsx
│       └── ThemeSwitcher.tsx
│
├── sections/
│   ├── Hero/
│   │   ├── HeroAI.tsx
│   │   ├── HeroCreative.tsx
│   │   ├── HeroCyber.tsx
│   │   ├── HeroLuxury.tsx
│   │   ├── HeroMotion.tsx
│   │   ├── HeroAgency.tsx
│   │   ├── HeroFreelancer.tsx
│   │   └── Hero3D.tsx
│   ├── StatsBar.tsx
│   ├── Ticker.tsx

│   ├── BentoGrid.tsx
│   ├── Services.tsx
│   ├── About.tsx
│   ├── Skills.tsx
│   ├── Timeline.tsx
│   ├── Testimonials.tsx
│   ├── Awards.tsx
│   ├── Pricing.tsx
│   ├── FAQ.tsx
│   ├── Contact.tsx
│   ├── Newsletter.tsx
│   └── Blog/
│       ├── BlogGrid.tsx
│       └── BlogPost.tsx
│
├── hooks/
│   ├── useScrollReveal.ts
│   ├── useMagneticButton.ts
│   ├── useParallax.ts
│   ├── useCountUp.ts
│   └── useTheme.ts
│
├── lib/
│   ├── animations.ts       # Framer Motion variants + easing presets
│   └── utils.ts            # cn(), clamp(), lerp(), mapRange(), slugify()
│                           # (use @/lib/utils — there is no separate utils/ folder)
│
├── constants/
│   ├── index.ts            # Re-exports all data: DEMOS, PROJECTS, SERVICES, PRICING
│   └── demos.ts            # Demo config objects (8 demos + DemoId type)
│                           # PROJECTS, SERVICES, PRICING are defined in constants/index.ts
│
├── types/
│   └── index.ts            # Shared TypeScript types (DemoId, Demo)
│
├── styles/
│   └── tokens.css          # All CSS custom properties — all 8 themes in one file
│                           # (no separate themes/ subfolder; themes are scoped
│                           #  by body class: body.t-cyber, body.t-luxury, etc.)
│
└── public/
    ├── fonts/
    ├── images/
    └── og/
```

---

## Installation

### Prerequisites
- Node.js 20+
- npm / yarn / pnpm

### Steps

```bash
# 1. Clone or extract the template
cd nexora

# 2. Install dependencies
npm install
# or
pnpm install

# 3. Set up environment variables
cp .env.local.example .env.local

# 4. Start development server
npm run dev

# 4. Open in browser
open http://localhost:3000
```

---

## Homepage Demos

### Switching Demos

In `app/page.tsx`, change the `activeDemo` prop:

```tsx
// app/page.tsx
import { DEMOS } from '@/constants/demos'

export default function HomePage() {
  return <HomepageLayout demo="ai" /> // change "ai" to any demo id
}
```

### Demo IDs

| ID | Name | Theme |
|----|------|-------|
| `ai` | AI Engineer | Purple/Cyan dark |
| `creative` | Creative Dev | Rose/Orange |
| `cyber` | Cybersecurity | Matrix green |
| `luxury` | Luxury Minimal | Gold/Navy |
| `motion` | Motion Designer | Violet/Fuchsia |
| `agency` | Agency | Bold monochrome |
| `freelancer` | Freelancer | Amber/Red warm |
| `3d` | Interactive 3D | Indigo/Cyan deep space |

---

## Sections Reference

### Hero Section
Each demo has a dedicated Hero component. The shared props interface:

```tsx
interface HeroProps {
  badge: string
  headline: React.ReactNode
  subheadline?: string
  extraContent?: React.ReactNode
  primaryCta: string
  secondaryCta: string
}
```

### Bento Grid
The project showcase grid. Configure in `constants/projects.ts`:

```ts
export const PROJECTS: Project[] = [
  {
    id: 'lumina',
    title: 'Lumina Design System',
    category: 'Featured Project',
    tags: ['Next.js', 'TypeScript', 'Figma'],
    span: 'large',           // 'large' | 'tall' | 'wide' | 'small'
    metric: { value: '240+', label: 'Components' },
  },
  // ...
]
```

### Animations
Scroll reveal is handled by a custom hook:

```tsx
import { useScrollReveal } from '@/hooks/useScrollReveal'

function MySection() {
  const ref = useScrollReveal({ threshold: 0.1, delay: 0.2 })
  return <div ref={ref}>Content</div>
}
```

---

## Theme Customization

### Changing Colors

All colors are CSS custom properties in `styles/tokens.css`:

```css
:root {
  /* Backgrounds */
  --bg: #050507;
  --deep: #0a0a0f;
  --surface: #0f0f18;
  --card: #141420;

  /* Text */
  --text: #f0f0f8;
  --muted: #7a7a99;

  /* Accents — change these to retheme instantly */
  --a: #8b5cf6;    /* Primary accent */
  --a2: #a78bfa;   /* Primary accent light */
  --b: #22d3ee;    /* Secondary accent */
  --b2: #67e8f9;   /* Secondary accent light */
  --c: #3b82f6;    /* Tertiary */
}
```

### Creating a Custom Theme

1. Add a new CSS file in `styles/themes/mytheme.css`
2. Override the custom properties:

```css
body.t-mytheme {
  --bg: #0a0005;
  --a: #ff0080;
  --a2: #ff66b3;
  --b: #00ffcc;
  --b2: #66ffee;
  --ff: 'Your Font', sans-serif;
}
```

3. Register in `constants/demos.ts`:

```ts
export const DEMOS = {
  // ...existing demos
  mytheme: {
    cls: 't-mytheme',
    badge: '...',
    // ...
  }
}
```

---

## Typography

### Font Configuration

Fonts are loaded in `app/layout.tsx` via `next/font/google`:

```tsx
import { Syne, DM_Sans, JetBrains_Mono } from 'next/font/google'

const syne = Syne({
  subsets: ['latin'],
  weight: ['400', '600', '700', '800'],
  variable: '--ff',
})

const dmSans = DM_Sans({
  subsets: ['latin'],
  weight: ['300', '400', '500'],
  variable: '--fb',
})
```

### Per-Demo Typography

Each demo can override the display font via CSS:

```css
body.t-luxury { --ff: 'Playfair Display', serif; }
body.t-cyber  { --ff: 'JetBrains Mono', monospace; }
```

---

## Animation Guide

### Framer Motion Page Transitions

```tsx
// lib/animations.ts
export const pageVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] } },
  exit: { opacity: 0, y: -20 }
}
```

### GSAP Scroll Triggers

```ts
// lib/gsap.ts
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

export function initHeroParallax(el: HTMLElement) {
  gsap.to(el, {
    yPercent: -30,
    ease: 'none',
    scrollTrigger: {
      trigger: el,
      start: 'top top',
      end: 'bottom top',
      scrub: true,
    },
  })
}
```

### Lenis Smooth Scroll

```tsx
// components/shared/SmoothScroll.tsx
import Lenis from '@studio-freight/lenis'

const lenis = new Lenis({ duration: 1.2, easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)) })
```

### Stagger Animations

```tsx
import { motion } from 'framer-motion'

const container = {
  animate: { transition: { staggerChildren: 0.08 } }
}
const item = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 }
}

function StaggeredList({ items }) {
  return (
    <motion.ul variants={container} initial="initial" animate="animate">
      {items.map(i => <motion.li key={i} variants={item}>{i}</motion.li>)}
    </motion.ul>
  )
}
```

---

## 3D Effects

The 3D demo uses React Three Fiber:

```tsx
// sections/Hero/Hero3D.tsx
import { Canvas } from '@react-three/fiber'
import { OrbitControls, Float, Stars } from '@react-three/drei'

export function Hero3D() {
  return (
    <Canvas camera={{ position: [0, 0, 5] }}>
      <Stars radius={80} depth={50} count={3000} factor={4} />
      <Float speed={2} rotationIntensity={0.5}>
        <mesh>
          <icosahedronGeometry args={[1.5, 1]} />
          <meshStandardMaterial color="#6366f1" wireframe />
        </mesh>
      </Float>
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} color="#818cf8" />
    </Canvas>
  )
}
```

---

## SEO Setup

Configure metadata in `app/layout.tsx`:

```tsx
export const metadata: Metadata = {
  title: { default: 'Your Name — Portfolio', template: '%s | Your Name' },
  description: 'Full-stack developer and designer crafting premium digital experiences.',
  openGraph: {
    title: 'Your Name — Portfolio',
    description: '...',
    images: [{ url: '/og/default.png', width: 1200, height: 630 }],
  },
  twitter: { card: 'summary_large_image' },
}
```

---

## Deployment

### Vercel (Recommended)

```bash
npm i -g vercel
vercel --prod
```

### Environment Variables

```env
# .env.local
NEXT_PUBLIC_SITE_URL=https://nexoraultra.netlify.app/
   # For contact form emails
RESEND_FROM_Esupporttemplyt@gmail.com
  # Must be a Resend-verified domain
CONTACT_EMAIL=supporttemplyt@gmail.com
       # Where form submissions are sent
```

### Contact Form with Resend

```ts
// app/api/contact/route.ts
import { Resend } from 'resend'
const resend = new Resend(process.env.RESEND_API_KEY)

export async function POST(req: Request) {
  const { name, email, message } = await req.json()
  await resend.emails.send({
    from: process.env.RESEND_FROM_EMAIL ?? 'onboarding@resend.dev',
    to: 'you@yoursite.com',
    subject: `New message from ${name}`,
    html: `<p>${message}</p>`,
  })
  return Response.json({ ok: true })
}
```

---

## FAQ

**Q: Can I use this for multiple clients?**
A: The Extended License covers unlimited end products for clients.

**Q: Is dark mode automatic?**
A: NEXORA defaults to dark. A `prefers-color-scheme` listener is included for optional system sync.

**Q: How do I add a new project to the bento grid?**
A: Add an entry to `constants/projects.ts` and set the `span` property.

**Q: Can I use a CMS?**
A: Yes. The template is pre-wired for Contentful, Sanity, and Notion API. See `docs/cms-setup.md` (included in the template).

**Q: Is accessibility covered?**
A: Yes. All interactive elements have ARIA labels, focus rings, and keyboard navigation. Passes WCAG AA.

---

## Support

- 📧 Email:supporttemplyt@gmail.com


---

*NEXORA v2.0.0 — © 2026. 
