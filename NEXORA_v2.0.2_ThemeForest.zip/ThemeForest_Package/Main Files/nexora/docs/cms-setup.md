# CMS Integration Guide

NEXORA is pre-wired to work with the three most popular headless CMS providers.
Choose the one that fits your workflow.

---

## Option 1 — Sanity

### Install

```bash
npm install next-sanity @sanity/image-url
npx sanity init
```

### Schema (sanity.config.ts)

```ts
import { defineConfig } from 'sanity'
import { deskTool } from 'sanity/desk'
import { schemaTypes } from './schemas'

export default defineConfig({
  name: 'nexora',
  title: 'NEXORA Content',
  projectId: 'YOUR_PROJECT_ID',
  dataset: 'production',
  plugins: [deskTool()],
  schema: { types: schemaTypes },
})
```

### Fetch blog posts

```ts
// lib/sanity.ts
import { createClient } from 'next-sanity'

export const client = createClient({
  projectId: process.env.NEXT_PUBLIC_SANITY_PROJECT_ID!,
  dataset: 'production',
  apiVersion: '2024-01-01',
  useCdn: true,
})

export async function getBlogPosts() {
  return client.fetch(`*[_type == "post"] | order(publishedAt desc) {
    _id, title, slug, excerpt, publishedAt, category
  }`)
}
```

### Environment variables

```env
NEXT_PUBLIC_SANITY_PROJECT_ID=your_project_id
SANITY_API_TOKEN=your_token
```

---

## Option 2 — Contentful

### Install

```bash
npm install contentful
```

### Fetch content

```ts
// lib/contentful.ts
import { createClient } from 'contentful'

const client = createClient({
  space: process.env.CONTENTFUL_SPACE_ID!,
  accessToken: process.env.CONTENTFUL_ACCESS_TOKEN!,
})

export async function getBlogPosts() {
  const entries = await client.getEntries({ content_type: 'blogPost' })
  return entries.items
}
```

### Environment variables

```env
CONTENTFUL_SPACE_ID=your_space_id
CONTENTFUL_ACCESS_TOKEN=your_access_token
```

---

## Option 3 — Notion API

### Install

```bash
npm install @notionhq/client notion-to-md
```

### Fetch from a Notion database

```ts
// lib/notion.ts
import { Client } from '@notionhq/client'

const notion = new Client({ auth: process.env.NOTION_TOKEN })

export async function getBlogPosts() {
  const response = await notion.databases.query({
    database_id: process.env.NOTION_DATABASE_ID!,
    filter: { property: 'Status', select: { equals: 'Published' } },
    sorts: [{ property: 'Published', direction: 'descending' }],
  })
  return response.results
}
```

### Environment variables

```env
NOTION_TOKEN=secret_xxxx
NOTION_DATABASE_ID=your_database_id
```

---

## Connecting to app/blog

Once your CMS client is set up, update `app/blog/page.tsx`:

```ts
// Replace the static POSTS array with:
import { getBlogPosts } from '@/lib/sanity' // or contentful / notion

export default async function BlogPage() {
  const posts = await getBlogPosts()
  // ...render posts
}
```

For `app/blog/[slug]/page.tsx`, fetch by slug:

```ts
export async function generateStaticParams() {
  const posts = await getBlogPosts()
  return posts.map(p => ({ slug: p.slug }))
}
```

---

## Questions?

See the main `DOCUMENTATION.md` or open a support ticket at the URL
listed in your ThemeForest purchase receipt.
