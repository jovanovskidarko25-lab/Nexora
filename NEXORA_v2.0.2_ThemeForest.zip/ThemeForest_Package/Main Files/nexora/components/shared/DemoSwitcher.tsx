'use client'

import { motion } from 'framer-motion'
import type { DemoId } from '@/constants/demos'

const BUTTONS: { id: DemoId; label: string }[] = [
  { id: 'ai',         label: '🤖 AI Eng' },
  { id: 'creative',   label: '🎨 Creative' },
  { id: 'cyber',      label: '🔐 Cyber' },
  { id: 'luxury',     label: '✦ Luxury' },
  { id: 'motion',     label: '🎬 Motion' },
  { id: 'agency',     label: '🏢 Agency' },
  { id: 'freelancer', label: '⚡ Freelance' },
  { id: '3d',         label: '🌐 3D' },
]

interface Props {
  activeDemo: DemoId
  onChange: (id: DemoId) => void
}

export default function DemoSwitcher({ activeDemo, onChange }: Props) {
  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 1, duration: 0.6 }}
      role="toolbar"
      aria-label="Switch demo theme"
      style={{
        position: 'fixed', bottom: 24, left: '50%', transform: 'translateX(-50%)',
        zIndex: 600, background: 'rgba(8,8,14,.93)', backdropFilter: 'blur(24px)',
        border: '1px solid var(--border2)', borderRadius: 100, padding: 5,
        display: 'flex', gap: 2, boxShadow: '0 8px 32px rgba(0,0,0,.5)',
        transition: 'border-color .4s', maxWidth: 'calc(100vw - 32px)',
        overflowX: 'auto',
      }}>
      {BUTTONS.map(btn => (
        <motion.button
          key={btn.id}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.96 }}
          onClick={() => onChange(btn.id)}
          aria-pressed={activeDemo === btn.id}
          style={{
            padding: '7px 13px', borderRadius: 100, fontSize: 11, fontWeight: 600,
            letterSpacing: '.2px', cursor: 'pointer', border: 'none',
            background: activeDemo === btn.id ? 'var(--a)' : 'transparent',
            color: activeDemo === btn.id ? '#fff' : 'var(--muted)',
            transition: 'all .2s', whiteSpace: 'nowrap', fontFamily: 'var(--fb)',
          }}>
          {btn.label}
        </motion.button>
      ))}
    </motion.div>
  )
}
