'use client'

import { motion } from 'framer-motion'
import { staggerContainer, staggerFade } from '@/lib/animations'
import { DEMOS } from '@/constants/demos'
import type { DemoId } from '@/constants/demos'

const DEMO_CARDS = Object.values(DEMOS).map((d, i) => ({
  ...d,
  num: String(i + 1).padStart(2, '0') + '/08',
  icon: ['🤖', '🎨', '🔐', '✦', '🎬', '🏢', '⚡', '🌐'][i],
}))

interface Props {
  activeDemo: DemoId
  onSelect: (id: DemoId) => void
}

export default function DemosGrid({ activeDemo, onSelect }: Props) {
  return (
    <div>
      <div
        style={{
          display: 'inline-flex', alignItems: 'center', gap: 8, fontSize: 10,
          letterSpacing: '2.5px', textTransform: 'uppercase', color: 'var(--a2)', marginBottom: 18,
        }}>
        <span style={{ width: 18, height: 1, background: 'var(--a2)' }} />
        Template Demos
      </div>
      <h2
        style={{
          fontFamily: 'var(--ff)', fontSize: 'clamp(32px,5vw,56px)', fontWeight: 800,
          letterSpacing: '-2px', lineHeight: 1.05, marginBottom: 14,
        }}>
        8 Unique Homepage Styles
      </h2>
      <p
        style={{
          fontSize: 16, color: 'var(--muted)', lineHeight: 1.75, fontWeight: 300,
          maxWidth: 460, marginBottom: 52,
        }}>
        Each demo is a completely different visual identity. Click any card to switch themes
        with a cinematic page transition.
      </p>

      <motion.div
        variants={staggerContainer(0.07)}
        initial="hidden"
        animate="show"
        style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 14 }}>
        {DEMO_CARDS.map(demo => (
          <motion.button
            key={demo.id}
            variants={staggerFade}
            onClick={() => onSelect(demo.id as DemoId)}
            whileHover={{ y: -5 }}
            type="button"
            aria-pressed={activeDemo === demo.id}
            style={{
              background: activeDemo === demo.id
                ? 'color-mix(in srgb,var(--a) 8%,var(--card))'
                : 'var(--card)',
              border: `1px solid ${activeDemo === demo.id ? 'var(--a)' : 'var(--border)'}`,
              borderRadius: 18, padding: 24, cursor: 'pointer', position: 'relative',
              overflow: 'hidden', transition: 'all .3s', textAlign: 'left',
              fontFamily: 'var(--fb)',
              /* Hover border/shadow via whileHover prop above; static style here */
              boxShadow: activeDemo === demo.id ? '0 20px 48px rgba(0,0,0,.4)' : 'none',
            }}>
            {/* Gradient overlay when active */}
            <div
              style={{
                position: 'absolute', inset: 0, borderRadius: 18,
                background: 'linear-gradient(135deg,var(--ga),var(--gb))',
                opacity: activeDemo === demo.id ? 1 : 0,
                transition: 'opacity .3s', pointerEvents: 'none',
              }}
            />

            <div style={{ position: 'relative' }}>
              <div
                style={{
                  fontFamily: 'var(--fm)', fontSize: 10, color: 'var(--muted2)',
                  marginBottom: 14, letterSpacing: '1px',
                }}>
                {demo.num}
              </div>
              <div
                style={{
                  width: 40, height: 40, borderRadius: 11,
                  background: 'color-mix(in srgb,var(--a) 14%,transparent)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 18, marginBottom: 16,
                }}
                aria-hidden="true">
                {demo.icon}
              </div>
              <div
                style={{
                  fontFamily: 'var(--ff)', fontSize: 14, fontWeight: 700,
                  letterSpacing: '-.3px', marginBottom: 6,
                }}>
                {demo.name}
              </div>
              <div style={{ fontSize: 12, color: 'var(--muted)', lineHeight: 1.55 }}>
                {demo.description}
              </div>
              <div style={{ marginTop: 12, fontSize: 10, color: 'var(--a2)', letterSpacing: '.5px' }}>
                {activeDemo === demo.id ? 'Active ↗' : 'Preview →'}
              </div>
            </div>
          </motion.button>
        ))}
      </motion.div>
    </div>
  )
}
