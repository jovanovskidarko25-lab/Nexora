'use client'

import { useEffect, useRef, useState } from 'react'

/**
 * CustomCursor
 * Only mounts on fine-pointer (mouse/trackpad) devices.
 * Touch and keyboard users see the default system cursor.
 */
export default function CustomCursor() {
  const dotRef  = useRef<HTMLDivElement>(null)
  const ringRef = useRef<HTMLDivElement>(null)
  const mouse   = useRef({ x: 0, y: 0 })
  const ring    = useRef({ x: 0, y: 0 })

  // Detect fine pointer before rendering — avoids flash on touch devices
  const [hasFinePointer, setHasFinePointer] = useState(false)

  useEffect(() => {
    setHasFinePointer(window.matchMedia('(pointer: fine)').matches)
  }, [])

  useEffect(() => {
    if (!hasFinePointer) return

    const dot = dotRef.current
    const r   = ringRef.current
    if (!dot || !r) return

    const onMove = (e: MouseEvent) => {
      mouse.current = { x: e.clientX, y: e.clientY }
      dot.style.left = e.clientX + 'px'
      dot.style.top  = e.clientY + 'px'
    }

    const onEnter = () => {
      dot.style.width = '14px'; dot.style.height = '14px'
      dot.style.background = 'var(--a2)'
      r.style.width = '52px'; r.style.height = '52px'
      r.style.borderColor = 'var(--a2)'
    }

    const onLeave = () => {
      dot.style.width = '7px'; dot.style.height = '7px'
      dot.style.background = 'var(--b)'
      r.style.width = '32px'; r.style.height = '32px'
      r.style.borderColor = 'color-mix(in srgb,var(--a) 50%,transparent)'
    }

    const interactables = document.querySelectorAll('a, button, [data-cursor="pointer"]')
    interactables.forEach(el => {
      el.addEventListener('mouseenter', onEnter)
      el.addEventListener('mouseleave', onLeave)
    })

    document.addEventListener('mousemove', onMove)

    let raf: number
    const loop = () => {
      ring.current.x += (mouse.current.x - ring.current.x) * 0.1
      ring.current.y += (mouse.current.y - ring.current.y) * 0.1
      r.style.left = ring.current.x + 'px'
      r.style.top  = ring.current.y + 'px'
      raf = requestAnimationFrame(loop)
    }
    loop()

    return () => {
      document.removeEventListener('mousemove', onMove)
      interactables.forEach(el => {
        el.removeEventListener('mouseenter', onEnter)
        el.removeEventListener('mouseleave', onLeave)
      })
      cancelAnimationFrame(raf)
    }
  }, [hasFinePointer])

  if (!hasFinePointer) return null

  const base: React.CSSProperties = {
    position: 'fixed', borderRadius: '50%',
    pointerEvents: 'none', zIndex: 9999,
    transform: 'translate(-50%,-50%)',
    transition: 'width .25s, height .25s, background .3s',
  }

  return (
    <>
      <div
        id="cursor"
        ref={dotRef}
        aria-hidden="true"
        style={{ ...base, width: 7, height: 7, background: 'var(--b)', mixBlendMode: 'screen' }}
      />
      <div
        id="cursor-ring"
        ref={ringRef}
        aria-hidden="true"
        style={{
          ...base, width: 32, height: 32, background: 'transparent',
          border: '1px solid color-mix(in srgb,var(--a) 50%,transparent)',
          transition: 'width .3s, height .3s, border-color .3s', zIndex: 9998,
        }}
      />
    </>
  )
}
