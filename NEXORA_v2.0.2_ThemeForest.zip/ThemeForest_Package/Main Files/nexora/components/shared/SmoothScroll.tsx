'use client'

import { useEffect } from 'react'

export default function SmoothScroll() {
  useEffect(() => {
    let cleanup: (() => void) | undefined

    import('@studio-freight/lenis').then(({ default: Lenis }) => {
      const lenis = new Lenis({
        duration: 1.2,
        easing: (t: number) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
        orientation: 'vertical',
        smoothWheel: true,
        touchMultiplier: 2,
      })

      let raf: number
      const run = (time: number) => { lenis.raf(time); raf = requestAnimationFrame(run) }
      raf = requestAnimationFrame(run)

      cleanup = () => { cancelAnimationFrame(raf); lenis.destroy() }
    })

    return () => cleanup?.()
  }, [])

  return null
}
