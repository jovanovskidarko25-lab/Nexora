'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useNavScroll, useMediaQuery } from '@/hooks'

const NAV_LINKS = [
  { label: 'Demos',    href: '#demos' },
  { label: 'Work',     href: '#work' },
  { label: 'Services', href: '#services' },
  { label: 'About',    href: '#about' },
  { label: 'Pricing',  href: '#pricing' },
  { label: 'Contact',  href: '#contact' },
]

export default function Navbar() {
  const scrolled = useNavScroll(50)
  const isMobile = useMediaQuery('(max-width: 900px)')
  const [mobileOpen, setMobileOpen] = useState(false)

  const handleNav = (href: string) => {
    setMobileOpen(false)
    const id = href.replace('#', '')
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <>
      <motion.nav
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        style={{
          position: 'fixed', top: 0, left: 0, right: 0, zIndex: 500,
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: isMobile ? '16px 20px' : '18px 52px',
          background: scrolled ? 'rgba(5,5,7,0.90)' : 'transparent',
          backdropFilter: scrolled ? 'blur(20px)' : 'none',
          borderBottom: scrolled ? '1px solid var(--border)' : '1px solid transparent',
          transition: 'all 0.4s cubic-bezier(0.16,1,0.3,1)',
        }}>

        {/* Logo */}
        <a
          href="/"
          style={{
            fontFamily: 'var(--ff)', fontSize: 18, fontWeight: 800,
            letterSpacing: '-.5px',
            background: 'linear-gradient(120deg,var(--text) 30%,var(--a2))',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
            textDecoration: 'none',
          }}>
          NEXORA
        </a>

        {/* Desktop links */}
        {!isMobile && (
          <ul style={{ display: 'flex', gap: 30, listStyle: 'none' }}>
            {NAV_LINKS.map(link => (
              <li key={link.label}>
                <button
                  onClick={() => handleNav(link.href)}
                  style={{
                    background: 'none', border: 'none', cursor: 'pointer',
                    color: 'var(--muted)', fontSize: 11, fontWeight: 500,
                    letterSpacing: '1px', textTransform: 'uppercase',
                    fontFamily: 'var(--fb)', transition: 'color .2s', padding: 0,
                  }}
                  onMouseEnter={e => (e.currentTarget.style.color = 'var(--text)')}
                  onMouseLeave={e => (e.currentTarget.style.color = 'var(--muted)')}>
                  {link.label}
                </button>
              </li>
            ))}
          </ul>
        )}

        {/* CTA (desktop) / Hamburger (mobile) */}
        {isMobile ? (
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={mobileOpen}
            style={{
              background: 'none', border: 'none',
              cursor: 'pointer', color: 'var(--text)', fontSize: 22, lineHeight: 1,
              padding: 4,
            }}>
            {mobileOpen ? '✕' : '☰'}
          </button>
        ) : (
          <motion.button
            whileHover={{ filter: 'brightness(1.15)', y: -1 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => handleNav('#contact')}
            style={{
              background: 'var(--a)', color: '#fff', padding: '9px 22px',
              borderRadius: 100, fontSize: 12, fontWeight: 600, letterSpacing: '.3px',
              border: 'none', cursor: 'pointer', transition: 'all .25s',
            }}>
            Let&apos;s Talk
          </motion.button>
        )}
      </motion.nav>

      {/* Mobile drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label="Navigation menu"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            style={{
              position: 'fixed', top: 57, left: 0, right: 0, zIndex: 499,
              background: 'rgba(5,5,7,.97)', backdropFilter: 'blur(20px)',
              borderBottom: '1px solid var(--border)', padding: '20px 24px 28px',
              display: 'flex', flexDirection: 'column', gap: 4,
            }}>
            {NAV_LINKS.map(link => (
              <button
                key={link.label}
                onClick={() => handleNav(link.href)}
                style={{
                  background: 'none', border: 'none', cursor: 'pointer',
                  color: 'var(--muted)', fontSize: 15, fontWeight: 500,
                  padding: '12px 4px', textAlign: 'left', fontFamily: 'var(--fb)',
                  transition: 'color .2s', borderBottom: '1px solid var(--border)',
                }}>
                {link.label}
              </button>
            ))}
            <button
              onClick={() => handleNav('#contact')}
              style={{
                marginTop: 12, background: 'var(--a)', color: '#fff',
                padding: '13px', borderRadius: 12, fontSize: 14, fontWeight: 600,
                border: 'none', cursor: 'pointer',
              }}>
              Let&apos;s Talk →
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
