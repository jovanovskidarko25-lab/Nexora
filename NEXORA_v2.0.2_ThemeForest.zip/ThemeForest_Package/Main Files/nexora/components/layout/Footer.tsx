'use client'

import { motion } from 'framer-motion'

const FOOTER_LINKS = {
  Template:  ['8 Homepage Demos', '20+ Sections', 'Documentation', 'Changelog', 'Roadmap'],
  Resources: ['Installation', 'Customization', 'Component Docs', 'Animation Guide', 'Support'],
  Connect:   ['Twitter / X', 'GitHub', 'LinkedIn', 'Dribbble', 'Email'],
}

export default function Footer() {
  return (
    <footer style={{ borderTop: '1px solid var(--border)', padding: '68px 52px 36px', position: 'relative' }}>
      {/* Top accent line */}
      <div
        style={{
          position: 'absolute', top: 0, left: 0, right: 0, height: 1,
          background: 'linear-gradient(90deg,transparent,var(--a),transparent)',
        }}
      />

      <div style={{ maxWidth: 1280, margin: '0 auto' }}>
        {/* Grid */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))',
            gap: 48, marginBottom: 56,
          }}>
          <div>
            <a
              href="/"
              style={{
                fontFamily: 'var(--ff)', fontSize: 18, fontWeight: 800,
                letterSpacing: '-.5px',
                background: 'linear-gradient(120deg,var(--text) 30%,var(--a2))',
                WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
                textDecoration: 'none', display: 'block', marginBottom: 12,
              }}>
              NEXORA
            </a>
            <p style={{ fontSize: 13, color: 'var(--muted)', lineHeight: 1.7, maxWidth: 250 }}>
              Ultra-premium React portfolio template for creative developers.
              Built with Next.js 15, TypeScript, and Framer Motion.
            </p>
            {/* Social icons */}
            <div style={{ display: 'flex', gap: 8, marginTop: 20 }}>
              {['𝕏', 'in', 'ⓖ', '◎'].map(icon => (
                <motion.a
                  key={icon}
                  href="#"
                  whileHover={{ borderColor: 'var(--a)', color: 'var(--a2)' }}
                  style={{
                    width: 32, height: 32, borderRadius: '50%',
                    border: '1px solid var(--border)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 12, cursor: 'pointer', transition: 'all .25s',
                    color: 'var(--muted)', textDecoration: 'none',
                  }}>
                  {icon}
                </motion.a>
              ))}
            </div>
          </div>

          {Object.entries(FOOTER_LINKS).map(([col, links]) => (
            <div key={col}>
              <div
                style={{
                  fontSize: 10, letterSpacing: '2px', textTransform: 'uppercase',
                  color: 'var(--muted2)', marginBottom: 16, fontWeight: 500,
                }}>
                {col}
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
                {links.map(link => (
                  <a
                    key={link}
                    href="#"
                    style={{
                      fontSize: 13, color: 'var(--muted)', textDecoration: 'none',
                      transition: 'color .2s',
                    }}
                    onMouseEnter={e => (e.currentTarget.style.color = 'var(--text)')}
                    onMouseLeave={e => (e.currentTarget.style.color = 'var(--muted)')}>
                    {link}
                  </a>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Bottom bar */}
        <div
          style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            paddingTop: 28, borderTop: '1px solid var(--border)', flexWrap: 'wrap', gap: 12,
          }}>
          <div style={{ fontSize: 12, color: 'var(--muted2)' }}>
            © 2026 NEXORA Template. Built with ♥ for ThemeForest.
          </div>
          <div style={{ display: 'flex', gap: 16, fontSize: 12, color: 'var(--muted2)' }}>
            {['License', 'Privacy', 'Terms'].map(label => (
              <a
                key={label}
                href="#"
                style={{ textDecoration: 'none', color: 'inherit', transition: 'color .2s' }}
                onMouseEnter={e => (e.currentTarget.style.color = 'var(--text)')}
                onMouseLeave={e => (e.currentTarget.style.color = 'var(--muted2)')}>
                {label}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  )
}
