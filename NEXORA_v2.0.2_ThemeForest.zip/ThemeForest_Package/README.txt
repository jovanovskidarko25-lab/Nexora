================================================
  NEXORA — Ultra Premium Portfolio Template
  Version 2.0.2
================================================

Thank you for purchasing NEXORA!

--------------------------------------------------
PACKAGE CONTENTS
--------------------------------------------------

  Main Files/nexora/    → Full Next.js 15 source code
  Documentation/        → index.html (open in browser)
  Licensing/LICENSE.txt → Regular & Extended license terms

--------------------------------------------------
QUICK START
--------------------------------------------------

  Requirements: Node.js 20+

  1. Extract the zip and open Main Files/nexora/
  2. npm install
  3. cp .env.local.example .env.local
     (edit .env.local with your values)
  4. npm run dev
  5. Open http://localhost:3000

--------------------------------------------------
FEATURES
--------------------------------------------------

  · 8 unique homepage demos (AI, Creative, Cyber,
    Luxury, Motion, Agency, Freelancer, 3D)
  · 20+ reusable section components
  · Next.js 15 App Router + React 19
  · TypeScript 5
  · Tailwind CSS v4
  · Framer Motion 11 + GSAP 3 animations
  · Lenis smooth scroll
  · React Three Fiber 3D hero
  · Full design token system (8 themes)
  · Contact form via Resend
  · CMS-ready (Sanity, Contentful, Notion)
  · WCAG 2.1 AA accessible
  · SEO metadata + Open Graph

--------------------------------------------------
DOCUMENTATION
--------------------------------------------------

  Open Documentation/index.html in any browser
  for the full reference guide including:
  installation, customization, theme system,
  animations, CMS setup, and deployment.

--------------------------------------------------
SUPPORT
--------------------------------------------------

  Email: supporttemplyt@gmail.com

  Please include your ThemeForest purchase code
  in all support requests.

--------------------------------------------------
LICENSE
--------------------------------------------------

  See Licensing/LICENSE.txt

  Regular License  = one end product
  Extended License = multiple / sold products

--------------------------------------------------
CHANGELOG
--------------------------------------------------

  v2.0.2 (2026-05-15) — WCAG 2.4 accessibility,
    controlled contact form, bug fixes

  v2.0.1 (2026-05-10) — Next.js 15 async params
    compatibility, import path fixes

  v2.0.0 (2026-05-10) — Major release, 8 demos,
    20+ sections, full design system

  v1.0.0 (2025-11-01) — Initial release

================================================
  NEXORA v2.0.2 · © 2026
================================================
